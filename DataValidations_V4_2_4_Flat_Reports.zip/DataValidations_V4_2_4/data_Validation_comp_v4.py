#!/usr/bin/env python3
"""Bigplay vs DaaS PySpark regression validator, Version 4.2.4.

This is an enhancement of the screenshot-based reconstruction, not the
byte-for-byte original. No pandas dependency. Run with spark-submit.

Preserved decision: the automatic key search checks candidate columns in their
original File1 order and *stops as soon as one column is unique and non-null
in both datasets*. This is a pragmatic uniqueness heuristic, not business-PK
inference. Optionally pass --composite to bypass it.

Examples:
  spark-submit data_Validation_comp_v4.py --bigplay_file bigplay.csv \\
      --daas_file daas.csv --username alice
  spark-submit data_Validation_comp_v3.py --config validation_v3_config.json
"""

import argparse
import json
import logging
import re
import os
import hashlib
from uuid import uuid4
from urllib.parse import urlparse, unquote
import sys
from datetime import datetime, timezone
from decimal import Decimal, InvalidOperation
from pathlib import Path
from time import perf_counter

from data_validation_dashboard import render_dashboard
from data_validation_fixedwidth import parse_fixed_width, validate_layout

from pyspark import StorageLevel
from pyspark.sql import SparkSession, functions as F
from pyspark.sql.types import NumericType

LOG = logging.getLogger('DataValidationV4')

# Stable report basenames; CSV outputs are real files rather than Spark directories.
ANALYSIS_FOLDER = 'analysis'
WIDE_OUTPUT = 'DataValidation_differencesall_records.csv'
MISSING_OUTPUT = 'DataValidation_differencesmissing_records.csv'
COLUMN_OUTPUT = 'DataValidation_differences_by_column'
COLUMN_SUMMARY = 'DataValidation_column_summary.csv'
SCHEMA_OUTPUT = 'DataValidation_schema_differences.csv'
CONVERSION_OUTPUT = 'DataValidation_invalid_conversions.csv'
KEY_SAMPLE_OUTPUT = 'DataValidation_top_affected_keys.csv'
RECON_OUTPUT = 'DataValidation_aggregate_reconciliation.csv'
QUALITY_OUTPUT = 'DataValidation_data_quality.csv'
SUMMARY_FILE = 'DataValidation_summary.json'
DASHBOARD_FILE = 'DataValidation_dashboard.html'
COLUMN_NAME_AUDIT = 'DataValidation_column_name_audit.csv'
RENAMED_COLUMNS = 'DataValidation_renamed_columns.csv'
MALFORMED_FILE1 = 'DataValidation_malformed_File1.csv'
MALFORMED_FILE2 = 'DataValidation_malformed_File2.csv'

DEFAULTS = {
    'inputs': {'File1': {'format': 'csv'}, 'File2': {'format': 'csv'}},
    'infer_schema': True,  # v2 compatible; set false for 00123/CUSIP preservation
    'null_values': ['NULL', ''],
    'exclude_columns': [],
    'numeric_columns': [],
    'column_types': {},  # optional source-type overrides, e.g. {"CUSIP":"string"}
    'rules': {},  # per-field numeric, tolerance, scale, case, trim, date_format
    'numeric_tolerance': '0',
    'rounding_scale': 4,
    'reconciliations': [],
    'required_columns': [],
    'thresholds': {},
    'spark': {'shuffle_partitions': 16, 'cache_inputs': True,
              'output_partitions': 8, 'single_csv_max_rows': 5000},
    'top_keys_limit': 20,
    'dashboard': {'enabled': True, 'sample_rows': 100, 'max_columns': 500},
    'file1_label': 'Bigplay',
    'file2_label': 'DaaS',
    # Optional manual cross-file names: each map is source header -> canonical name.
    'column_aliases': {'File1': {}, 'File2': {}},
    'logging': {'spark_level': 'ERROR', 'console_level': 'WARNING',
                'file_level': 'DEBUG', 'console_progress': False},
    'fail_on_schema_change': False,
    'fail_on_invalid_conversion': True,
}


def qcol(name):
    """Column reference safe for spaces, periods, and backticks."""
    return F.col('`' + name.replace('`', '``') + '`')


def ac(alias, name):
    return F.col('`' + alias.replace('`', '``') + '`.`' + name.replace('`', '``') + '`')


def normalize_name(name):
    return name.strip().replace(' ', '_')


def dec(value, label='numeric value'):
    try:
        number = Decimal(str(value))
    except (InvalidOperation, TypeError, ValueError) as exc:
        raise ValueError(f'Invalid {label}: {value!r}') from exc
    if not number.is_finite() or number < 0:
        raise ValueError(f'{label} must be non-negative and finite: {value!r}')
    return number


def load_config(path):
    if not path:
        return {}
    path = Path(path)
    with path.open(encoding='utf-8') as handle:
        if path.suffix.lower() in ('.yaml', '.yml'):
            try:
                import yaml
            except ImportError as exc:
                raise ValueError('YAML requires PyYAML; use JSON instead.') from exc
            data = yaml.safe_load(handle)
        else:
            data = json.load(handle)
    if not isinstance(data, dict):
        raise ValueError('Configuration must be a JSON/YAML object.')
    return data


def configuration(args):
    user = load_config(args.config)
    unknown = set(user) - set(DEFAULTS) - {
        'bigplay_file', 'daas_file', 'username', 'composite',
        'output_dir', 'run_id', 'log_file',
    }
    if unknown:
        raise ValueError('Unrecognized configuration settings: ' + ', '.join(sorted(unknown)))
    cfg = {**DEFAULTS, **user}
    cfg['spark'] = {**DEFAULTS['spark'], **user.get('spark', {})}
    if not isinstance(user.get('dashboard', {}), dict):
        raise ValueError('dashboard settings must be an object.')
    cfg['dashboard'] = {**DEFAULTS['dashboard'], **user.get('dashboard', {})}
    if not isinstance(user.get('logging', {}), dict):
        raise ValueError('logging settings must be a JSON object.')
    cfg['logging'] = {**DEFAULTS['logging'], **user.get('logging', {})}
    for setting in ('spark_level', 'console_level', 'file_level'):
        value = str(cfg['logging'][setting]).upper()
        if value not in ('DEBUG', 'INFO', 'WARN', 'WARNING', 'ERROR', 'FATAL', 'CRITICAL', 'OFF'):
            raise ValueError(f'Invalid logging.{setting}: {value}')
        cfg['logging'][setting] = value
    if not isinstance(cfg['logging']['console_progress'], bool):
        raise ValueError('logging.console_progress must be true or false')
    aliases = user.get('column_aliases', {})
    if not isinstance(aliases, dict) or set(aliases) - {'File1', 'File2'}:
        raise ValueError('column_aliases must contain only File1 and/or File2 objects.')
    cfg['column_aliases'] = {'File1': {}, 'File2': {}}
    for label, values in aliases.items():
        if not isinstance(values, dict) or any(not isinstance(k, str) or not isinstance(v, str) or not k.strip() or not v.strip()
                                                for k, v in values.items()):
            raise ValueError(f'column_aliases.{label} must map nonempty source header names to column names.')
        cfg['column_aliases'][label] = values
    inputs = user.get('inputs', {})
    if not isinstance(inputs, dict) or set(inputs) - {'File1', 'File2'}:
        raise ValueError('inputs must contain only File1 and/or File2 objects.')
    cfg['inputs'] = {'File1': {'format': 'csv'}, 'File2': {'format': 'csv'}}
    for label, options in inputs.items():
        if not isinstance(options, dict):
            raise ValueError(f'inputs.{label} must be an object.')
        format_name = str(options.get('format', 'csv')).lower()
        if format_name == 'csv':
            if set(options) - {'format'}:
                raise ValueError(f'inputs.{label}: CSV needs only format; standard CSV options remain global.')
            cfg['inputs'][label] = {'format': 'csv'}
        elif format_name in ('fixed_width', 'fixed-width', 'fwf'):
            field_spec = {**options, 'format': 'fixed_width'}
            validate_layout(field_spec, f'inputs.{label}')
            cfg['inputs'][label] = field_spec
        else:
            raise ValueError(f'inputs.{label}: format must be csv or fixed_width.')
    for name in ('bigplay_file', 'daas_file', 'username', 'output_dir', 'run_id'):
        if getattr(args, name) is not None:
            cfg[name] = getattr(args, name)
    if args.composite is not None:
        cfg['composite'] = args.composite
    if args.numeric_tolerance is not None:
        cfg['numeric_tolerance'] = args.numeric_tolerance
    if getattr(args, 'log_file', None) is not None:
        cfg['log_file'] = args.log_file
    if getattr(args, 'spark_log_level', None) is not None:
        cfg['logging']['spark_level'] = str(args.spark_log_level).upper()
        if cfg['logging']['spark_level'] not in ('DEBUG', 'INFO', 'WARN', 'ERROR', 'FATAL', 'OFF'):
            raise ValueError('Invalid --spark_log_level setting.')
    if not cfg.get('bigplay_file') or not cfg.get('daas_file'):
        raise ValueError('Provide both --bigplay_file and --daas_file (or set them in --config).')
    if not cfg.get('output_dir') and not cfg.get('username'):
        raise ValueError('Supply either --output_dir or --username (possibly in the config).')
    if isinstance(cfg.get('username'), list):
        cfg['username'] = cfg['username'][0] if cfg['username'] else None
    if cfg.get('username') and not re.fullmatch(r'[A-Za-z0-9_.-]+', cfg['username']):
        raise ValueError('username must be a simple Unix username.')
    if not isinstance(cfg['rules'], dict) or not isinstance(cfg['thresholds'], dict):
        raise ValueError('rules and thresholds must be JSON objects.')
    if not isinstance(cfg['spark'], dict):
        raise ValueError('spark settings must be a JSON object.')
    if not isinstance(cfg['column_types'], dict):
        raise ValueError('column_types must map field names to Spark SQL datatypes.')
    for k in ('shuffle_partitions', 'output_partitions'):
        if int(cfg['spark'][k]) < 1:
            raise ValueError(f'spark.{k} must be positive.')
    if int(cfg['spark']['single_csv_max_rows']) < 0:
        raise ValueError('spark.single_csv_max_rows must be zero or greater.')
    if int(cfg['dashboard']['sample_rows']) < 0 or int(cfg['dashboard']['sample_rows']) > 2000:
        raise ValueError('dashboard.sample_rows must be 0 through 2000.')
    if int(cfg['dashboard']['max_columns']) < 0 or int(cfg['dashboard']['max_columns']) > 10000:
        raise ValueError('dashboard.max_columns must be 0 through 10000.')
    if not isinstance(cfg['dashboard']['enabled'], bool):
        raise ValueError('dashboard.enabled must be a boolean.')
    if not 0 <= int(cfg['rounding_scale']) <= 10:
        raise ValueError('rounding_scale must be 0 through 10.')
    dec(cfg['numeric_tolerance'], 'numeric_tolerance')
    for k, rule in cfg['rules'].items():
        if not isinstance(rule, dict):
            raise ValueError(f'Rule for {k} must be an object.')
        if 'tolerance' in rule:
            dec(rule['tolerance'], f'rules.{k}.tolerance')
        if 'scale' in rule and not 0 <= int(rule['scale']) <= 10:
            raise ValueError(f'rules.{k}.scale must be between 0 and 10.')
    supported_thresholds = {'max_missing_rows', 'max_mismatch_records',
                            'max_mismatch_pct', 'max_schema_differences',
                            'max_invalid_casts', 'max_reconciliation_failures',
                            'max_required_nulls'}
    if set(cfg['thresholds']) - supported_thresholds:
        raise ValueError('Unknown thresholds: ' + str(sorted(set(cfg['thresholds']) - supported_thresholds)))
    for k, v in cfg['thresholds'].items():
        dec(v, f'thresholds.{k}')
    run = cfg.get('run_id') or datetime.now(timezone.utc).strftime('%Y%m%dT%H%M%S%fZ')
    if not re.fullmatch(r'[A-Za-z0-9_.-]+', str(run)):
        raise ValueError('run_id must be a simple folder name.')
    base = cfg.get('output_dir') or f'file:///home/{cfg["username"]}/'
    cfg['run_dir'] = base.rstrip('/') + '/DataValidation_v4/' + str(run)
    # The Python log is a DRIVER-LOCAL file. HDFS/S3 output cannot be opened by
    # Python's logging.FileHandler, so fall back to the driver's home folder.
    parsed = urlparse(cfg['run_dir'])
    if parsed.scheme in ('', 'file') and (not parsed.netloc or parsed.netloc == 'localhost'):
        default_log = str(Path(unquote(parsed.path)).expanduser() / 'DataValidation_run.log')
    else:
        default_log = str(Path.home() / 'DataValidation_Logs' / f'{run}.log')
    cfg['log_file'] = cfg.get('log_file') or default_log
    return cfg


def describe_source_headers(original_names, canonical_names, label, alias_names):
    """Audit only names actually changed at input normalization/mapping time.

    This does not pretend that arbitrary File1 and File2 headers are semantically
    equivalent. Spark dataframe aliases `a` and `b` are reported separately.
    """
    if len(original_names) != len(canonical_names):
        raise ValueError('Column name lineage must cover all input fields.')
    rows = []
    for original, canonical in zip(original_names, canonical_names):
        normalized = normalize_name(original)
        explicit = (original in alias_names or normalized in alias_names)
        normalized_change = original != normalized
        if explicit and normalized_change:
            change_type = 'NORMALIZED_AND_EXPLICIT_RENAME'
        elif explicit:
            change_type = 'EXPLICIT_RENAME' if canonical != normalized else 'EXPLICIT_MAPPING_NO_CHANGE'
        elif normalized_change:
            change_type = 'HEADER_NORMALIZED'
        else:
            change_type = 'UNCHANGED'
        rows.append({'File': label, 'Original_column': original,
                     'Normalized_column': normalized, 'Comparison_column': canonical,
                     'Change_type': change_type})
    return rows


def map_source_headers(original_names, cfg, label):
    aliases = cfg.get('column_aliases', {}).get(label, {})
    # Reject alias directives that don't apply to an actual input header.
    present = set(original_names) | {normalize_name(name) for name in original_names}
    unknown = set(aliases) - present
    if unknown:
        raise ValueError(f'column_aliases.{label} references nonexistent columns: {sorted(unknown)}')
    canonical = [normalize_name(aliases.get(name, aliases.get(normalize_name(name),
                                                            normalize_name(name))))
                 for name in original_names]
    if not canonical or any(not n for n in canonical) or len(canonical) != len(set(x.casefold() for x in canonical)):
        raise ValueError(f'Empty/duplicate/case-ambiguous comparison headers in {label}.')
    return canonical, describe_source_headers(original_names, canonical, label, aliases)


def annotate_column_lineage(file1, file2, keys, compare, ignored):
    """Add why a mapped column was/wasn't used in a comparison."""
    all_1 = {r['Comparison_column'] for r in file1}
    all_2 = {r['Comparison_column'] for r in file2}
    out = []
    for label, rows in (('File1', file1), ('File2', file2)):
        other = all_2 if label == 'File1' else all_1
        for row in rows:
            c = row['Comparison_column']
            role = ('EXCLUDED' if c in ignored else 'ONLY_IN_ONE_FILE' if c not in other
                    else 'PRIMARY_KEY' if c in keys else 'COMPARED' if c in compare
                    else 'NOT_COMPARED')
            out.append({**row, 'Role': role,
                        'Spark_join_reference': ('a' if label == 'File1' else 'b') + '.' + c
                        if role in ('PRIMARY_KEY', 'COMPARED') else ''})
    return out


def setup_run_logging(cfg):
    """Save a Python debug/exception trail without flooding stdout."""
    path = Path(cfg['log_file']).expanduser()
    path.parent.mkdir(parents=True, exist_ok=True)
    fmt = logging.Formatter('%(asctime)s %(levelname)-7s %(name)s %(message)s')
    # Only manage our logger; do not alter unrelated Python logging subsystems.
    for handler in list(LOG.handlers):
        LOG.removeHandler(handler)
        handler.close()
    LOG.setLevel(logging.DEBUG)
    LOG.propagate = False

    def level(name):
        return {'WARN': logging.WARNING, 'WARNING': logging.WARNING,
                'FATAL': logging.CRITICAL, 'CRITICAL': logging.CRITICAL,
                'OFF': 100}.get(name, getattr(logging, name, 100))

    file_handler = logging.FileHandler(path, mode='a', encoding='utf-8')
    file_handler.setFormatter(fmt)
    file_handler.setLevel(level(cfg['logging']['file_level']))
    LOG.addHandler(file_handler)
    error_path = path.with_name('DataValidation_errors.log')
    error_handler = logging.FileHandler(error_path, mode='a', encoding='utf-8')
    error_handler.setFormatter(fmt)
    error_handler.setLevel(logging.ERROR)
    LOG.addHandler(error_handler)
    cfg['error_log_file'] = str(error_path)
    console_handler = logging.StreamHandler(sys.stderr)
    console_handler.setFormatter(fmt)
    console_handler.setLevel(level(cfg['logging']['console_level']))
    LOG.addHandler(console_handler)
    try:
        os.chmod(path, 0o600)
        os.chmod(error_path, 0o600)
    except OSError:
        pass  # Filesystem ACLs may be managed by site policy.
    LOG.info('Starting validation. Log file: %s; error file: %s', path, error_path)
    LOG.info('Run output location: %s', cfg['run_dir'])
    return path


def load_data(spark, uri, config, label='File1', return_audit=False, return_meta=False):
    """Read CSV or fixed-width text and normalize headers consistently.

    Backward compatible: return (df, issues) unless return_audit is requested;
    return_meta is used by run() to audit fixed-width layout problems.
    """
    source = config.get('inputs', {}).get(label, {'format': 'csv'})
    if source.get('format', 'csv') == 'fixed_width':
        df, cast_errors, meta = parse_fixed_width(spark, uri, source,
                                                   config['null_values'], label)
    else:
        df = (spark.read.option('header', 'true')
              .option('inferSchema', str(bool(config['infer_schema'])).lower())
              .csv(uri))
        cast_errors = []
        meta = {'format': 'csv', 'malformed_rows': 0, 'layout': []}
    canonical, audit = map_source_headers(df.columns, config, label)
    df = df.toDF(*canonical)
    string_columns = [f.name for f in df.schema.fields if f.dataType.simpleString() == 'string']
    for col in string_columns:
        for token in config['null_values']:
            df = df.withColumn(col, F.when(qcol(col) == F.lit(str(token)),
                                           F.lit(None)).otherwise(qcol(col)))
    type_overrides = {normalize_name(k): v for k, v in config['column_types'].items()}
    for name in type_overrides:
        if name not in df.columns:
            raise ValueError(f'column_types references missing input column: {name}')
    if type_overrides:
        exprs = [F.sum(F.when(qcol(name).isNotNull() & qcol(name).cast(dtype).isNull(), 1)
                       .otherwise(0)).alias(f'e{i}')
                 for i, (name, dtype) in enumerate(type_overrides.items())]
        measured = df.agg(*exprs).first()
        for i, name in enumerate(type_overrides):
            bad = int(measured[f'e{i}'] or 0)
            if bad:
                cast_errors.append((name, bad, 'INVALID_EXPLICIT_TYPE'))
    for name, sql_type in type_overrides.items():
        df = df.withColumn(name, qcol(name).cast(sql_type))
    if return_meta:
        return df, cast_errors, audit, meta
    if return_audit:
        return df, cast_errors, audit
    return df, cast_errors


def schema_report(file1, file2, ignored):
    types1 = {x.name: x.dataType.simpleString() for x in file1.schema.fields}
    types2 = {x.name: x.dataType.simpleString() for x in file2.schema.fields}
    rows = []
    for name in sorted(set(types1) | set(types2)):
        if name in ignored:
            continue
        if name not in types1:
            issue = 'MISSING_IN_FILE1'
        elif name not in types2:
            issue = 'MISSING_IN_FILE2'
        elif types1[name] != types2[name]:
            issue = 'TYPE_MISMATCH'
        else:
            continue
        rows.append((name, issue, types1.get(name), types2.get(name)))
    return rows


def read_keys(cfg):
    raw = cfg.get('composite') or []
    if isinstance(raw, str):
        raw = [raw]
    parts = [normalize_name(piece) for item in raw for piece in item.split('+') if piece.strip()]
    if len(parts) != len(set(parts)):
        raise ValueError('Duplicate composite key component names supplied.')
    return parts


def first_unique_key(file1, file2, common, n1, n2):
    """KEEP requested early-exit algorithm; no exhaustive search after success."""
    if n1 == 0 or n2 == 0:
        raise ValueError('Automatic key detection needs two nonempty datasets.')
    for name in common:  # preserves File1 column order
        LOG.info('Checking candidate primary key: %s', name)
        unique1 = file1.agg(F.countDistinct(qcol(name)).alias('n')).first()['n']
        if unique1 != n1:
            continue
        unique2 = file2.agg(F.countDistinct(qcol(name)).alias('n')).first()['n']
        if unique2 == n2:
            LOG.info('Using first unique candidate: %s; stopping key search.', name)
            return [name], name
        LOG.info('Candidate %s not unique/non-null in File2; continuing.', name)
    raise ValueError('No unique non-null column found in both datasets. Use --composite.')


def validate_explicit_keys(df, components, label):
    for name in components:
        if name not in df.columns:
            raise ValueError(f'{label} does not contain key column {name!r}.')
    null_check = None
    for name in components:
        term = qcol(name).isNull()
        null_check = term if null_check is None else null_check | term
    if df.where(null_check).limit(1).count():
        raise ValueError(f'{label}: supplied composite key contains NULL values.')
    if df.groupBy(*[qcol(x) for x in components]).count().where(F.col('count') > 1).limit(1).count():
        raise ValueError(f'{label}: supplied composite key is not unique.')


def key_condition(keys):
    """No delimiter concatenation: composite keys cannot collide."""
    condition = None
    for name in keys:
        # String conversion avoids Spark implicit numerical coercion of IDs.
        piece = ac('a', name).cast('string') == ac('b', name).cast('string')
        condition = piece if condition is None else (condition & piece)
    return condition


def key_expression(alias, keys):
    """Single-key PK; composite PK is a structured JSON identifier."""
    if len(keys) == 1:
        return ac(alias, keys[0]).cast('string')
    return F.to_json(F.struct(*[ac(alias, k).cast('string').alias(k) for k in keys]))


def should_write_single_csv(row_count, max_rows):
    """Keep small reports readable without serializing arbitrarily large datasets."""
    return int(max_rows) > 0 and int(row_count) <= int(max_rows)


def name_single_csv_part(spark, destination, filename):
    """Rename the sole Spark part file *within* its existing CSV directory.

    Works on local file:// and Hadoop file systems; does not collect rows
    into the driver. Other Spark output directories remain untouched.
    """
    if '/' in filename or '\\' in filename or not filename.lower().endswith('.csv'):
        raise ValueError('The CSV output filename must be a simple .csv basename.')
    jvm = spark._jvm
    directory = jvm.org.apache.hadoop.fs.Path(destination)
    filesystem = directory.getFileSystem(spark._jsc.hadoopConfiguration())
    parts = [item.getPath() for item in filesystem.listStatus(directory)
             if item.isFile() and item.getPath().getName().startswith('part-')
             and item.getPath().getName().endswith('.csv')]
    if len(parts) != 1:
        raise RuntimeError(f'Expected one CSV part at {destination}, found {len(parts)}.')
    named = jvm.org.apache.hadoop.fs.Path(directory, filename)
    if filesystem.exists(named):
        raise RuntimeError(f'Output filename already exists: {named}')
    if not filesystem.rename(parts[0], named):
        raise RuntimeError(f'Could not rename the CSV part to {named}')
    LOG.info('Saved single combined CSV to %s', named)
    return str(named)


def write_csv(df, destination, partitions=None, small_rows=None, filename=None):
    if filename and small_rows is None:
        raise ValueError('A named single CSV output requires small_rows to be set.')
    if small_rows is not None:
        df = df.coalesce(1)  # one Spark task, only for bounded reports
    elif partitions is not None:
        df = df.repartition(int(partitions))
    df.write.mode('overwrite').option('header', 'true').csv(destination)
    if filename:
        name_single_csv_part(df.sparkSession, destination, filename)
    LOG.info('Saved %s', destination)


def filesystem_path(spark, uri):
    """Return Hadoop FileSystem and Path for local file:// or a shared filesystem."""
    path = spark._jvm.org.apache.hadoop.fs.Path(uri)
    return path.getFileSystem(spark._jsc.hadoopConfiguration()), path


def promote_csv(spark, source, destination):
    """Move one fully-written Spark CSV part into its final, flat filename."""
    fs, dest = filesystem_path(spark, destination)
    if not fs.mkdirs(dest.getParent()) and not fs.exists(dest.getParent()):
        raise RuntimeError(f'Could not create output directory {dest.getParent()}')
    if fs.exists(dest):
        # Older versions wrote a directory using this same report basename.
        if not fs.delete(dest, True):
            raise RuntimeError(f'Could not replace existing output {destination}')
    if not fs.rename(source, dest):
        raise RuntimeError(f'Could not publish output CSV: {destination}')
    LOG.info('Published %s', destination)


def write_flat_csv(df, destination):
    """Write a CSV as a FILE, not a directory, using a temporary Spark folder.

    We intentionally use one output task for each overall/analysis report.
    This is suitable for interactive validation exports; for very large
    reports a single task/file can be a throughput and file-size bottleneck.
    """
    spark = df.sparkSession
    staging = destination + '.__spark_stage_' + uuid4().hex
    fs, stage = filesystem_path(spark, staging)
    try:
        (df.coalesce(1).write.mode('errorifexists')
         .option('header', 'true').option('maxRecordsPerFile', 0)
         .csv(staging))
        parts = [item.getPath() for item in fs.listStatus(stage)
                 if item.isFile() and item.getPath().getName().startswith('part-')
                 and item.getPath().getName().endswith('.csv')]
        if len(parts) != 1:
            raise RuntimeError(f'Expected exactly one output CSV part, got {len(parts)}: {staging}')
        promote_csv(spark, parts[0], destination)
    finally:
        if fs.exists(stage):
            fs.delete(stage, True)


def csv_from_rows(spark, rows, schema, destination):
    """Create one flat CSV containing small analysis/metadata tables."""
    df = spark.createDataFrame(rows, schema)
    write_flat_csv(df, destination)


def per_column_csv_name(column):
    """Collision-resistant, filesystem-safe, human-readable column report name."""
    safe = re.sub(r'[^A-Za-z0-9_.-]+', '_', str(column)).strip('._-')[:80] or 'column'
    suffix = hashlib.sha256(str(column).encode('utf-8')).hexdigest()[:8]
    return f'Column_{safe}_{suffix}.csv'


def write_flat_column_reports(detail, columns, analysis_dir, output_partitions):
    """Shuffle once by affected column; flatten partition output into one CSV
    per affected column in the shared analysis folder (no nested folders).
    """
    if not columns:
        return {}
    spark = detail.sparkSession
    names = {str(i).zfill(5): (str(col), per_column_csv_name(col))
             for i, col in enumerate(sorted(columns))}
    expressions = []
    for key, (column, _) in names.items():
        expressions += [F.lit(column), F.lit(key)]
    keyed = detail.withColumn('_output_file_key', F.create_map(*expressions)[F.col('Column_affected')])
    staging = analysis_dir.rstrip('/') + '/.__column_stage_' + uuid4().hex
    fs, stage = filesystem_path(spark, staging)
    published = {}
    try:
        (keyed.repartition(int(output_partitions), F.col('_output_file_key'))
         .write.mode('errorifexists').option('header', 'true')
         .option('maxRecordsPerFile', 0)
         .partitionBy('_output_file_key').csv(staging))
        dirs = [item.getPath() for item in fs.listStatus(stage) if item.isDirectory()]
        for part_dir in dirs:
            dirname = part_dir.getName()
            if not dirname.startswith('_output_file_key='):
                continue
            token = dirname.split('=', 1)[1]
            if token not in names:
                raise RuntimeError(f'Unexpected column partition name: {dirname}')
            column, filename = names[token]
            parts = [item.getPath() for item in fs.listStatus(part_dir)
                     if item.isFile() and item.getPath().getName().startswith('part-')
                     and item.getPath().getName().endswith('.csv')]
            if len(parts) != 1:
                raise RuntimeError(f'Expected one CSV part for {column}, got {len(parts)}')
            promote_csv(spark, parts[0], analysis_dir.rstrip('/') + '/' + filename)
            published[column] = 'analysis/' + filename
        if len(published) != len(names):
            raise RuntimeError('Column CSV publishing incomplete; some columns missing')
        return published
    finally:
        if fs.exists(stage):
            fs.delete(stage, True)


def write_text(spark, destination, content):
    """Use Hadoop FileSystem APIs to support local file:, HDFS, and object stores."""
    jvm = spark._jvm
    path = jvm.org.apache.hadoop.fs.Path(destination)
    fs = path.getFileSystem(spark._jsc.hadoopConfiguration())
    fs.mkdirs(path.getParent())
    # OutputStreamWriter sends a Java UTF-8 string and supports Hadoop FS URIs
    # without relying on Py4J's Python bytearray -> Java byte[] conversion.
    stream = fs.create(path, True)
    writer = jvm.java.io.OutputStreamWriter(stream, 'UTF-8')
    try:
        writer.write(content)
        writer.flush()
    finally:
        writer.close()


def parse_rules(cfg, compare, file1, file2):
    """Resolve options without modifying original values written to reports."""
    recon_metrics = {normalize_name(x) for task in cfg['reconciliations']
                     for x in task.get('sum_columns', [])}
    unknown = (set(map(normalize_name, cfg['rules'])) |
               set(map(normalize_name, cfg['numeric_columns'])) | recon_metrics) - set(compare)
    if unknown:
        raise ValueError(f'rules/numeric_columns reference excluded or nonexistent columns: {sorted(unknown)}')
    rules = {}
    explicit_numeric = {normalize_name(x) for x in cfg['numeric_columns']}
    # Reconciliation SUM columns must also undergo safe numeric comparisons.
    for task in cfg['reconciliations']:
        explicit_numeric.update(normalize_name(x) for x in task.get('sum_columns', []))
    for name in compare:
        r = cfg['rules'].get(name, cfg['rules'].get(name.replace('_', ' '), {}))
        inferred_numeric = (isinstance(file1.schema[name].dataType, NumericType) or
                            isinstance(file2.schema[name].dataType, NumericType))
        is_numeric = bool(r.get('numeric', name in explicit_numeric or inferred_numeric))
        is_date = bool(r.get('date_format') or r.get('kind') == 'date')
        if is_numeric and is_date:
            raise ValueError(f'{name}: cannot simultaneously be date and numeric.')
        if 'tolerance' in r and not is_numeric:
            raise ValueError(f'{name}: tolerance was specified for a non-numeric column. Set numeric=true.')
        rules[name] = {
            'numeric': is_numeric,
            'date_format': r.get('date_format', 'yyyy-MM-dd') if is_date else None,
            'tolerance': dec(r.get('tolerance', cfg['numeric_tolerance']), f'{name}.tolerance'),
            'scale': int(r.get('scale', cfg['rounding_scale'])),
            'case_sensitive': bool(r.get('case_sensitive', True)),
            'trim_whitespace': bool(r.get('trim_whitespace', False)),
        }
    return rules


def comparable(raw, rule):
    """Normalize a comparison expression, preserving original report values."""
    if rule['numeric']:
        return F.round(raw.cast('decimal(38,10)'), rule['scale'])
    if rule['date_format']:
        return F.to_date(raw.cast('string'), rule['date_format'])
    value = raw.cast('string')
    if rule['trim_whitespace']:
        value = F.trim(value)
    if not rule['case_sensitive']:
        value = F.lower(value)
    return value


def discrepancy_condition(a, b, rule):
    if not rule['numeric']:
        return ~a.eqNullSafe(b)
    threshold = F.lit(str(rule['tolerance'])).cast('decimal(38,10)')
    return ((a.isNull() & b.isNotNull()) |
            (a.isNotNull() & b.isNull()) |
            (a.isNotNull() & b.isNotNull() & (F.abs(a - b) > threshold)))


def conversion_counts(file1, file2, compare, rules):
    """One aggregate action per file, not one count() per numerical column."""
    conversion_fields = {c: r for c, r in rules.items() if r['numeric'] or r['date_format']}
    rows = []
    for label, df in (('File1', file1), ('File2', file2)):
        if not conversion_fields:
            continue
        measures = [F.sum(F.when(qcol(name).isNotNull() & comparable(qcol(name), rule).isNull(), 1)
                          .otherwise(0)).alias(f'c{n}')
                    for n, (name, rule) in enumerate(conversion_fields.items())]
        result = df.agg(*measures).first()
        for i, name in enumerate(conversion_fields):
            bad = int(result[f'c{i}'] or 0)
            if bad:
                rows.append((label, name, bad, 'INVALID_NUMERIC' if rules[name]['numeric'] else 'INVALID_DATE'))
    return rows


def required_null_counts(file1, file2, required):
    if not required:
        return []
    data = []
    for label, df in (('File1', file1), ('File2', file2)):
        for name in required:
            if name not in df.columns:
                raise ValueError(f'{label}: missing required column {name}.')
        aggregations = [F.sum(F.when(qcol(name).isNull(), 1).otherwise(0)).alias(f'n{i}')
                        for i, name in enumerate(required)]
        row = df.agg(*aggregations).first()
        data.extend([(label, name, int(row[f'n{i}'] or 0), 'REQUIRED_NULL')
                     for i, name in enumerate(required) if row[f'n{i}']])
    return data


def make_difference_frames(file1, file2, keys, compare, rules):
    """Create one join and cache only affected matched-key records.

    Returns (cached mismatching join, combined wide file, long per-column file).
    """
    joined = file1.alias('a').join(file2.alias('b'), key_condition(keys), 'inner')
    conds, normals = {}, {}
    for name in compare:
        l = comparable(ac('a', name), rules[name])
        r = comparable(ac('b', name), rules[name])
        normals[name] = (l, r)
        conds[name] = discrepancy_condition(l, r, rules[name])

    # Use a non-ambiguous internal temporary column name.
    if '__dv3_affected' in file1.columns or '__dv3_affected' in file2.columns:
        raise ValueError('Reserved column __dv3_affected already exists in input data.')
    affected = F.concat_ws(',', *[F.when(conds[name], F.lit(name)) for name in compare])
    base = joined.withColumn('__dv3_affected', affected).where(qcol('__dv3_affected') != '').persist(StorageLevel.MEMORY_AND_DISK)

    # Build paired expressions; the writer later projects ONLY columns that
    # actually have discrepancies somewhere in this run.
    wide = base.select(
        key_expression('a', keys).alias(keys[0] if len(keys) == 1 else 'composite_key'),
        qcol('__dv3_affected').alias('Columns_effected'),
        *[ac('a', c).alias('uat_' + c) for c in compare],
        *[ac('b', c).alias('prod_' + c) for c in compare],
    )

    details = []
    for name in compare:
        r = rules[name]
        a, b = normals[name]
        if r['numeric']:
            difference = b - a
            pct = F.when(a.isNotNull() & (a != 0), (difference / F.abs(a)) * F.lit(100))
        else:
            difference = F.lit(None).cast('decimal(38,10)')
            pct = F.lit(None).cast('double')
        dtype = (F.when((a.isNull() & b.isNotNull()) | (a.isNotNull() & b.isNull()),
                        F.lit('NULL_MISMATCH'))
                 .otherwise(F.lit('NUMERIC_DIFFERENCE' if r['numeric']
                                  else 'DATE_DIFFERENCE' if r['date_format'] else 'TEXT_DIFFERENCE')))
        details.append(F.when(conds[name], F.struct(
            F.lit(name).alias('Column_affected'),
            ac('a', name).cast('string').alias('File1'),
            ac('b', name).cast('string').alias('File2'),
            dtype.alias('Difference_type'),
            difference.cast('decimal(38,10)').alias('Numeric_Difference'),
            F.abs(difference).cast('decimal(38,10)').alias('Absolute_Difference'),
            F.round(pct, 4).cast('double').alias('Percentage_Difference'),
        )))
    long = (base.select(key_expression('a', keys).alias('PK'),
                        F.explode(F.array(*details)).alias('d'))
            .where(F.col('d').isNotNull())
            .select('PK', 'd.Column_affected', 'd.File1', 'd.File2',
                    'd.Difference_type', 'd.Numeric_Difference',
                    'd.Absolute_Difference', 'd.Percentage_Difference'))
    return base, wide, long


def impacted_wide_report(wide, keys, compared, impacted):
    """One row per affected PK, with paired File1/File2 values for impacted columns only.

    An impacted column means at least one record failed the effective comparison
    rule in this run. All rows share the same (stable) schema; for a row where a
    globally impacted column matches, the equal values remain visible. This
    avoids collecting/pivoting all mismatches back to the driver.
    """
    impacted = set(impacted)
    unknown = impacted - set(compared)
    if unknown:
        raise ValueError(f'Impacted columns not part of comparison: {sorted(unknown)}')
    pk = keys[0] if len(keys) == 1 else 'composite_key'
    fields = [qcol(pk), qcol('Columns_effected')]
    for name in compared:
        if name in impacted:
            fields.extend((qcol('uat_' + name).alias('File1_' + name),
                           qcol('prod_' + name).alias('File2_' + name)))
    return wide.select(*fields)


def missing_frame(file1, file2, keys, columns):
    """Both directions, safe for composite keys and dissimilar source column order."""
    left_only = (file1.alias('a').join(file2.alias('b'), key_condition(keys), 'left_anti')
                 .select(F.lit('File2').alias('Missing_from'),
                         key_expression('a', keys).alias('PK'),
                         *[ac('a', c).cast('string').alias(c) for c in columns]))
    right_only = (file2.alias('b').join(file1.alias('a'), key_condition(keys), 'left_anti')
                  .select(F.lit('File1').alias('Missing_from'),
                          key_expression('b', keys).alias('PK'),
                          *[ac('b', c).cast('string').alias(c) for c in columns]))
    return left_only.unionByName(right_only)


def aggregate_reconciliation(file1, file2, settings):
    """Group totals in each file; returns a long comparison of selected metrics."""
    output = []
    for i, task in enumerate(settings):
        name = task.get('name', f'reconciliation_{i + 1}')
        groups = [normalize_name(x) for x in task.get('group_by', [])]
        totals = [normalize_name(x) for x in task.get('sum_columns', [])]
        if not totals:
            raise ValueError(f'Reconciliation {name} requires sum_columns.')
        for col in groups + totals:
            if col not in file1.columns or col not in file2.columns:
                raise ValueError(f'Reconciliation {name} refers to missing column: {col}.')
        tol = dec(task.get('tolerance', '0'), f'{name}.tolerance')
        def agg(df):
            return (df.groupBy(*[qcol(g) for g in groups])
                    .agg(F.count(F.lit(1)).alias('__rows_present'),
                         *[F.sum(qcol(c).cast('decimal(38,10)')).alias('sum_' + str(j))
                           for j, c in enumerate(totals)]))
        left, right = agg(file1).alias('a'), agg(file2).alias('b')
        join_cond = None
        for g in groups:
            cond = ac('a', g).eqNullSafe(ac('b', g))
            join_cond = cond if join_cond is None else join_cond & cond
        if not groups:
            # Spark global aggregation returns one row even for an empty input.
            joined = left.crossJoin(right)
            group_str = F.lit('ALL')
        else:
            joined = left.join(right, join_cond, 'full_outer')
            group_str = F.to_json(F.struct(*[F.coalesce(ac('a', g), ac('b', g)).cast('string').alias(g) for g in groups]))
        metric_rows = []
        for j, column in enumerate(totals):
            a, b = ac('a', 'sum_' + str(j)), ac('b', 'sum_' + str(j))
            delta = b - a
            # Check whether a grouping is present, even when SUM is NULL.
            absent = ac('a', '__rows_present').isNull() | ac('b', '__rows_present').isNull()
            failed = absent | discrepancy_condition(a, b, {'numeric': True, 'tolerance': tol})
            metric_rows.append(F.struct(
                F.lit(name).alias('Reconciliation'), group_str.alias('Group'),
                F.lit(column).alias('Metric'), a.alias('File1_total'), b.alias('File2_total'),
                delta.alias('Difference'),
                F.when(failed, F.lit('FAIL')).otherwise(F.lit('PASS')).alias('Status'),
            ))
        output.append(joined.select(F.explode(F.array(*metric_rows)).alias('x')).select('x.*'))
    if not output:
        return None
    result = output[0]
    for frame in output[1:]:
        result = result.unionByName(frame)
    return result


def get_summary_status(result, cfg):
    metrics = {
        'max_missing_rows': result['missing_rows'],
        'max_mismatch_records': result['mismatched_records'],
        'max_mismatch_pct': result['mismatch_pct_of_matched'],
        'max_schema_differences': result['schema_difference_count'],
        'max_invalid_casts': result['invalid_conversions'],
        'max_reconciliation_failures': result['reconciliation_failures'],
        'max_required_nulls': result['required_nulls'],
    }
    failures = []
    for name, ceiling in cfg['thresholds'].items():
        if Decimal(str(metrics[name])) > dec(ceiling, name):
            failures.append(f'{name}: {metrics[name]} exceeds {ceiling}')
    if cfg['fail_on_schema_change'] and result['schema_difference_count']:
        failures.append('Schema differences detected')
    if cfg['fail_on_invalid_conversion'] and result['invalid_conversions']:
        failures.append('Invalid numeric/date conversions detected')
    if failures:
        return 'FAIL', failures

    # An explicitly configured threshold only permits that named metric.
    # A threshold for numeric differences must not silently approve schema
    # changes, missing records, or a failed aggregate reconciliation.
    configured = set(cfg['thresholds'])
    uncovered = []
    metric_thresholds = {
        'missing_rows': {'max_missing_rows'},
        'mismatched_records': {'max_mismatch_records', 'max_mismatch_pct'},
        'schema_difference_count': {'max_schema_differences'},
        'reconciliation_failures': {'max_reconciliation_failures'},
        'required_nulls': {'max_required_nulls'},
        'invalid_conversions': {'max_invalid_casts'},
    }
    for metric, limits in metric_thresholds.items():
        if result[metric] and not (limits & configured):
            uncovered.append(metric)
    if uncovered:
        return 'REVIEW', [f'Unapproved differences in: {", ".join(uncovered)}.']
    if any(result[m] for m in metric_thresholds):
        return 'PASS', ['All detected differences are within explicitly configured thresholds.']
    return 'PASS', []


def run(spark, cfg):
    started = perf_counter()
    last = started
    timings = {}

    def mark(name):
        nonlocal last
        now = perf_counter()
        timings[name] = round(now - last, 4)
        last = now

    # Treat invalid numeric/date casts as NULL, then capture their original
    # non-NULL values in conversion_counts(). Spark 4 defaults ANSI on;
    # turning it off avoids aborting the entire job before error reporting.
    spark.conf.set('spark.sql.ansi.enabled', 'false')
    root = cfg['run_dir']
    analysis_dir = root + '/' + ANALYSIS_FOLDER
    log_context = {'File1_label': cfg['file1_label'], 'File2_label': cfg['file2_label']}
    f1, explicit_err1, audit1, meta1 = load_data(spark, cfg['bigplay_file'], cfg, 'File1', return_meta=True)
    f2, explicit_err2, audit2, meta2 = load_data(spark, cfg['daas_file'], cfg, 'File2', return_meta=True)
    for label, meta, name in (('File1', meta1, MALFORMED_FILE1), ('File2', meta2, MALFORMED_FILE2)):
        if meta['format'] == 'fixed_width':
            LOG.info('%s fixed-width layout: %d columns, record length %d, bad lines %d',
                     label, len(meta['layout']), meta['record_length'], meta['malformed_rows'])
            # Always produce an auditable malformed-record report, even empty.
            write_flat_csv(meta['malformed_frame'], analysis_dir + '/' + name)
            if meta['malformed_rows']:
                if meta['on_malformed'] == 'fail':
                    raise ValueError(f'{label}: {meta["malformed_rows"]} malformed fixed-width records. '
                                     f'See {analysis_dir}/{name} ; comparison stopped.')
    mark('load_inputs_and_normalize')
    ignored = set(map(normalize_name, cfg['exclude_columns']))
    schema_rows = schema_report(f1, f2, ignored)
    all_common = [c for c in f1.columns if c in f2.columns]
    if not all_common:
        raise ValueError('Input files have no columns in common.')
    components = read_keys(cfg)
    if components and any(x in ignored for x in components):
        raise ValueError('Cannot exclude a primary-key column.')
    compare = [c for c in all_common if c not in ignored and c not in components]
    if not compare:
        raise ValueError('No comparable non-key columns remain.')
    # Key detection operates on source values before comparison normalization.
    if cfg['spark']['cache_inputs']:
        f1.persist(StorageLevel.MEMORY_AND_DISK)
        f2.persist(StorageLevel.MEMORY_AND_DISK)
    try:
        n1, n2 = f1.count(), f2.count()
        if components:
            validate_explicit_keys(f1, components, 'File1')
            validate_explicit_keys(f2, components, 'File2')
            keys, key_label = components, '+'.join(components)
        else:
            candidates = [c for c in all_common if c not in ignored]
            keys, key_label = first_unique_key(f1, f2, candidates, n1, n2)
            compare = [c for c in compare if c not in keys]
        if not compare:
            raise ValueError('No non-key fields remain to compare.')
        LOG.info('Comparison key: %s; compared columns: %s', key_label, len(compare))
        audit = annotate_column_lineage(audit1, audit2, keys, compare, ignored)
        renamed = [item for item in audit if item['Original_column'] != item['Comparison_column']]
        audit_schema = ('File string,Original_column string,Normalized_column string,'
                        'Comparison_column string,Change_type string,Role string,Spark_join_reference string')
        fields = ('File', 'Original_column', 'Normalized_column', 'Comparison_column',
                  'Change_type', 'Role', 'Spark_join_reference')
        csv_from_rows(spark, [tuple(row[k] for k in fields) for row in audit],
                      audit_schema, analysis_dir + '/' + COLUMN_NAME_AUDIT)
        csv_from_rows(spark, [tuple(row[k] for k in fields) for row in renamed],
                      audit_schema, analysis_dir + '/' + RENAMED_COLUMNS)
        LOG.info('Column name audit: %d headers checked, %d changed.', len(audit), len(renamed))
        mark('row_counts_and_key_detection')
        rules = parse_rules(cfg, compare, f1, f2)
        conversion_rows = ([('File1', *r) for r in explicit_err1] +
                           [('File2', *r) for r in explicit_err2] +
                           conversion_counts(f1, f2, compare, rules))
        required = [normalize_name(x) for x in cfg['required_columns']]
        quality_rows = required_null_counts(f1, f2, required)
        mark('comparison_rules_and_quality')

        csv_from_rows(spark, schema_rows, 'Column string,Issue string,File1_type string,File2_type string',
                      analysis_dir + '/' + SCHEMA_OUTPUT)
        csv_from_rows(spark, conversion_rows, 'File string,Column string,Invalid_rows long,Issue string',
                      analysis_dir + '/' + CONVERSION_OUTPUT)
        csv_from_rows(spark, quality_rows, 'File string,Column string,Null_rows long,Issue string',
                      analysis_dir + '/' + QUALITY_OUTPUT)
        mark('write_schema_and_quality_reports')

        # Align shared fields and no others; schema-only differences are separately reported.
        shared = [c for c in all_common if c not in ignored]
        a = f1.select(*[qcol(c) for c in shared])
        b = f2.select(*[qcol(c) for c in shared])
        base, wide, detail = make_difference_frames(a, b, keys, compare, rules)
        try:
            # Materialize the cached discrepancy subset for reusable reports.
            mismatch_n = base.count()
            mark('join_and_identify_discrepancies')

            # Calculate matched-key denominator BEFORE per-column statistics.
            missing = missing_frame(a, b, keys, shared)
            missing.persist(StorageLevel.MEMORY_AND_DISK)
            try:
                missing_counts = {r['Missing_from']: r['count'] for r in
                                  missing.groupBy('Missing_from').count().collect()}
                missing_n = sum(missing_counts.values())
                write_flat_csv(missing, root + '/' + MISSING_OUTPUT)
            finally:
                missing.unpersist()
            mark('missing_key_reports')
            matched = n1 - int(missing_counts.get('File2', 0))
            top_limit = int(cfg['top_keys_limit'])
            column_stats = []
            dashboard_sample = []
            if mismatch_n:
                # Detailed per-column files are published after summary counts below.
                counts = (detail.groupBy('Column_affected')
                          .agg(F.count('*').alias('Mismatch_rows'),
                               F.sum(F.when(F.col('Difference_type') == 'NULL_MISMATCH', 1).otherwise(0)).alias('Null_mismatch_rows'),
                               F.max('Absolute_Difference').alias('Max_absolute_difference'))
                          .withColumn('Mismatch_pct_of_matched',
                                      F.round(F.col('Mismatch_rows') * F.lit(100.0 / matched), 4)
                                      if matched else F.lit(None).cast('double')))
                column_stats = [dict(row.asDict()) for row in counts.collect()]
                impacted = {r['Column_affected'] for r in column_stats if r['Mismatch_rows'] > 0}
                column_csv_files = write_flat_column_reports(
                    detail, impacted, analysis_dir, cfg['spark']['output_partitions'])
                impacted_wide = impacted_wide_report(wide, keys, compare, impacted)
                # Collecting column statistics only collects one row per affected
                # COLUMN, never 22k+ mismatch records. Projection is lazy and
                # reuses the already cached discrepancy subset.
                write_flat_csv(impacted_wide, root + '/' + WIDE_OUTPUT)
                LOG.info('Combined report contains %d impacted columns of %d compared.',
                         len(impacted), len(compare))
                # Intentionally bounded: never collect all mismatches on the driver.
                # Spark limit is a preview, not a representative statistical sample.
                if cfg['dashboard']['enabled'] and int(cfg['dashboard']['sample_rows']) > 0:
                    dashboard_sample = [row.asDict() for row in
                                        detail.limit(int(cfg['dashboard']['sample_rows'])).collect()]
                write_flat_csv(counts.orderBy(F.desc('Mismatch_rows')), analysis_dir + '/' + COLUMN_SUMMARY)
                if top_limit > 0:
                    most_affected = (detail.groupBy('PK')
                                     .agg(F.count('*').alias('Mismatching_columns'))
                                     .orderBy(F.desc('Mismatching_columns'), 'PK').limit(top_limit))
                    write_flat_csv(most_affected, analysis_dir + '/' + KEY_SAMPLE_OUTPUT)
            else:
                column_csv_files = {}
                LOG.info('No value-level differences found.')
                # Explicitly create an empty combined report, useful for automation.
                write_flat_csv(impacted_wide_report(wide, keys, compare, set()),
                               root + '/' + WIDE_OUTPUT)
                csv_from_rows(spark, [],
                              'Column_affected string,Mismatch_rows long,Null_mismatch_rows long,Max_absolute_difference decimal(38,10),Mismatch_pct_of_matched double',
                              analysis_dir + '/' + COLUMN_SUMMARY)
            mark('difference_reports_and_preview')

            recon = aggregate_reconciliation(f1, f2, cfg['reconciliations'])
            recon_fail = 0
            recon_total = 0
            if recon is not None:
                recon.persist(StorageLevel.MEMORY_AND_DISK)
                try:
                    recon_metrics = {r['Status']: r['count'] for r in recon.groupBy('Status').count().collect()}
                    recon_fail = int(recon_metrics.get('FAIL', 0))
                    recon_total = sum(recon_metrics.values())
                    write_flat_csv(recon, analysis_dir + '/' + RECON_OUTPUT)
                finally:
                    recon.unpersist()
            mark('aggregate_reconciliations')

            result = {
                'version': '4.2.4', 'run_dir': root, 'inputs': {
                    'File1': cfg['bigplay_file'], 'File2': cfg['daas_file'], **log_context,
                }, 'primary_key': key_label, 'primary_key_columns': keys,
                'pk_strategy': 'first non-null unique column in both files; early exit' if not components else 'explicit composite',
                'file1_rows': n1, 'file2_rows': n2, 'matched_keys': matched,
                'mismatched_records': mismatch_n,
                'mismatch_pct_of_matched': round(mismatch_n * 100.0 / matched, 6) if matched else 0.0,
                'missing_rows': missing_n,
                'missing_from_file1': int(missing_counts.get('File1', 0)),
                'missing_from_file2': int(missing_counts.get('File2', 0)),
                'schema_difference_count': len(schema_rows),
                'schema_differences': [dict(zip(('Column', 'Issue', 'File1_type', 'File2_type'), row)) for row in schema_rows],
                'invalid_conversions': sum(row[2] for row in conversion_rows),
                'input_formats': {'File1': meta1['format'], 'File2': meta2['format']},
                'fixed_width_layouts': {'File1': meta1.get('layout', []), 'File2': meta2.get('layout', [])},
                'malformed_rows': meta1['malformed_rows'] + meta2['malformed_rows'],
                'malformed_from_file1': meta1['malformed_rows'],
                'malformed_from_file2': meta2['malformed_rows'],
                'required_nulls': sum(row[2] for row in quality_rows),
                'reconciliation_groups': recon_total,
                'reconciliation_failures': recon_fail,
                'combined_csv_single_file': True,
                'report_layout': 'flat',
                'analysis_dir': analysis_dir,
                'column_report_files': column_csv_files,
                'columns_compared': compare,
                'impacted_columns': [c for c in compare if c in {r['Column_affected'] for r in column_stats}],
                'column_mismatch_summary': column_stats,
                'excluded_columns': sorted(ignored),
                'renamed_columns_count': len(renamed),
                'renamed_columns': renamed,
                'column_audit_count': len(audit),
                'log_file': str(cfg['log_file']),
                'error_log_file': str(cfg.get('error_log_file', '')),
                'numeric_columns': [k for k, v in rules.items() if v['numeric']],
                'thresholds': cfg['thresholds'],
            }
            result['status'], result['status_reasons'] = get_summary_status(result, cfg)
            if result['malformed_rows']:
                # Invalid physical records are NEVER silently approved, even in
                # report mode: omitted input records make reconciliation suspect.
                result['status'] = 'FAIL'
                result['status_reasons'].append(
                    f'{result["malformed_rows"]} malformed fixed-width rows were excluded; see malformed CSV reports.')
            if result['status'] == 'FAIL':
                LOG.error('Validation rules FAILED: %s', '; '.join(result['status_reasons']))
            elif result['status'] == 'REVIEW':
                LOG.warning('Validation requires REVIEW: %s', '; '.join(result['status_reasons']))
            mark('summarize_results')
            result['dashboard_sample_limit'] = int(cfg['dashboard']['sample_rows']) if cfg['dashboard']['enabled'] else 0
            result['dashboard_generated'] = bool(cfg['dashboard']['enabled'])
            result['timings_seconds'] = dict(timings)
            if cfg['dashboard']['enabled']:
                dashboard = render_dashboard(result, dashboard_sample,
                                             max_columns=int(cfg['dashboard']['max_columns']))
                write_text(spark, root + '/' + DASHBOARD_FILE, dashboard)
                mark('write_html_dashboard')
            result['timings_seconds'] = dict(timings)
            result['timings_seconds']['total_before_summary_write'] = round(perf_counter() - started, 4)
            write_text(spark, root + '/' + SUMMARY_FILE, json.dumps(result, indent=2, default=str) + '\n')
            LOG.info('Run completed: %s | file1=%s file2=%s matched=%s mismatched=%s missing=%s',
                     result['status'], n1, n2, matched, mismatch_n, missing_n)
            return result
        finally:
            base.unpersist()
    finally:
        if cfg['spark']['cache_inputs']:
            f1.unpersist()
            f2.unpersist()


def main(argv=None):
    parser = argparse.ArgumentParser(description='PySpark Bigplay vs DaaS CSV/fixed-width regression validator (v4.2.4).')
    parser.add_argument('--config', help='JSON settings file; YAML if PyYAML is installed')
    parser.add_argument('--bigplay_file', help='File1 path (legacy interface)')
    parser.add_argument('--daas_file', help='File2 path (legacy interface)')
    parser.add_argument('--username', nargs='+', help='Legacy Hadoop username; first value used')
    parser.add_argument('--composite', nargs='+', help='Explicit key columns, separated by + or spaces')
    parser.add_argument('--output_dir', help='Base folder URI for results')
    parser.add_argument('--run_id', help='Unique output folder for this run')
    parser.add_argument('--numeric_tolerance', help='Default allowable absolute difference')
    parser.add_argument('--log_file', help='Driver-local Python log path; defaults inside local run folder')
    parser.add_argument('--spark_log_level', choices=['ERROR','WARN','INFO','DEBUG','OFF'],
                        help='Spark JVM console verbosity (default ERROR)')
    args = parser.parse_args(argv)
    try:
        cfg = configuration(args)
    except (ValueError, OSError, json.JSONDecodeError) as exc:
        parser.error(str(exc))
    try:
        setup_run_logging(cfg)
    except (OSError, ValueError) as exc:
        parser.error(f'Unable to open local log file: {exc}')
    LOG.info('Configured Spark log level: %s', cfg['logging']['spark_level'])
    # Do not force master=local: use spark-submit --master / cluster defaults.
    # Spark bootstrap errors should also enter the Python error log.
    try:
        spark = (SparkSession.builder.appName('DataValidationV4')
                 .config('spark.sql.shuffle.partitions', str(cfg['spark']['shuffle_partitions']))
                 .config('spark.ui.showConsoleProgress', str(cfg['logging']['console_progress']).lower())
                 .getOrCreate())
        spark.sparkContext.setLogLevel(cfg['logging']['spark_level'])
    except Exception:
        LOG.exception('Spark could not start or its log level could not be set.')
        print('Spark startup failed. See: ' + str(cfg['log_file']), file=sys.stderr)
        return 3
    try:
        result = run(spark, cfg)
        print(json.dumps({k: result[k] for k in ('status', 'run_dir', 'primary_key',
                                               'mismatched_records', 'missing_rows',
                                               'reconciliation_failures', 'renamed_columns_count',
                                               'malformed_rows', 'input_formats',
                                               'log_file', 'error_log_file')}, indent=2))
        return 2 if result['status'] == 'FAIL' else 0
    except Exception:
        LOG.exception('Validation failed; traceback saved to %s', cfg['log_file'])
        print('Validation failed. See Python error log: ' + str(cfg['log_file']), file=sys.stderr)
        return 3
    finally:
        spark.stop()
        for handler in list(LOG.handlers):
            handler.flush()


if __name__ == '__main__':
    sys.exit(main())
