# DataValidations V4.3.0 — Cloudera/Spark 3 regression tool

A complete follow-on release to **V4.2.5**, preserving the existing PK and comparison behavior while adding frequent discrepancy patterns, validation trends, export scaling, safety/audit files and Excel summaries.

## Quick start on Cloudera

Copy these **four Python files** together into `/home/svarma`:

- `data_Validation_comp_v4.py` — main Spark application (entry point name preserved)
- `data_validation_dashboard.py` — offline HTML generator
- `data_validation_fixedwidth.py` — optional fixed-width TXT parser
- `data_validation_v43.py` — patterns, history, reproducibility and XLSX helpers (**new required dependency**)

Also copy and edit `validation_v43.example.json` to set the correct input paths/fields and run ID. This example uses `/home/svarma/tmp/dv-results` as the output root. For fixed-width TXT inputs, keep using the `inputs.File1` and `inputs.File2` layout objects from `validation_fixedwidth.example.json` (included).

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py,/home/svarma/data_validation_v43.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_v43.json \
  --run_id AccumRC_v43_001 \
  --spark_log_level WARN
```

The input paths shown in the example JSON are **placeholders**, not actual business files. Use your validated paths.

Existing CLI parameters are also supported:

```bash
spark3-submit --master 'local[2]' \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py,/home/svarma/data_validation_v43.py \
  /home/svarma/data_Validation_comp_v4.py \
  --bigplay_file file:///home/svarma/nonprod/input.csv \
  --daas_file file:///home/svarma/prod/input.csv \
  --output_dir file:///home/svarma/tmp/dv-results \
  --run_id example_001 --spark_log_level WARN
```

Set `--composite POLICY_ID+DATE` to override the automatic PK heuristic, if desired. By default the tool stops checking candidates as soon as one column is unique and non-null in both files.

For a **TXT-to-TXT** or **TXT-to-CSV** test, start with the included `validation_fixedwidth.example.json` or `validation_csv_vs_fixedwidth.example.json`. The field positions in examples are not production layouts.

## Run directory (new run IDs only)

```
/home/svarma/tmp/dv-results/DataValidation_v4/AccumRC_v43_001/
├── DataValidation_differencesall_records.csv
├── DataValidation_differencesmissing_records.csv
├── DataValidation_dashboard.html
├── DataValidation_summary.json
├── DataValidation_summary.xlsx                  <-- NEW
├── DataValidation_config_snapshot.json          <-- NEW
├── DataValidation_run_manifest.json             <-- NEW, written last
├── DataValidation_run.log
├── DataValidation_errors.log
└── analysis/
    ├── DataValidation_column_report_index.csv
    ├── DataValidation_column_summary.csv
    ├── Column_wbwithdrawaldelay_differences.csv
    ├── DataValidation_discrepancy_patterns.csv   <-- NEW when mismatches exist
    ├── DataValidation_run_comparison.csv         <-- NEW if baseline provided
    ├── DataValidation_schema_differences.csv
    ├── DataValidation_renamed_columns.csv
    └── ... other schema, quality, and reconciliation CSVs
```

If **more than 250,000** rows require an overall export, `adaptive` mode may write root-level
`DataValidation_differencesall_records__part_00000.csv`, `...__part_00001.csv`, etc. instead of the one combined filename. Missing-records exports follow the same policy. All parts stay directly in the **run root**, and the HTML output list links to each part. Column-level reports stay as single named CSVs directly in `analysis/`.

## 1. Discrepancy pattern analysis

The `analysis/DataValidation_discrepancy_patterns.csv` includes frequent observations of three types:

| Pattern_type | Meaning |
|---|---|
| `VALUE_PAIR` | Frequent (Non-Production value, Production value) pairs, grouped by discrepancy type |
| `PRODUCTION_VALUE` | Frequent Production values across mismatched rows, even if Non-Production values vary (helps detect defaulting) |
| `DIFFERENCE_TYPE` | Frequency of numeric/text/date/NULL mismatch classes |

The output includes column name, pattern type, source values where applicable, and `Occurrences`. Per-column top N is configurable; the dashboard/JSON embeds only a bounded subset. Patterns are explanatory **clues**, not claims of causal diagnosis.

```json
"patterns": {"enabled": true, "top_per_column": 6, "max_summary_rows": 300}
```

## 2. Compare against a previous run

For a second run, use a unique `--run_id` and pass the prior completed summary:

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py,/home/svarma/data_validation_v43.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_v43.json \
  --run_id AccumRC_v43_002 \
  --compare_run file:///home/svarma/tmp/dv-results/DataValidation_v4/AccumRC_v43_001/DataValidation_summary.json
```

Or set `"history": {"baseline_summary": "file:///.../DataValidation_summary.json"}` inside your JSON configuration. PK components, compared columns and input formats must agree between runs. This compares **aggregate counts** and column-level changes (NEWLY_AFFECTED, NO_LONGER_AFFECTED, INCREASED, DECREASED, UNCHANGED), not which individual policy records changed. Use the original CSVs for detailed root-cause work.

## 3. CSV export controls

```json
"export": {
  "large_report_mode": "adaptive",
  "large_report_threshold_rows": 250000,
  "large_report_partitions": 8
}
```

`adaptive` preserves one actual root-level CSV for smaller output and, for large overall outputs, produces multiple **root-level** shards without nested folders. Set `large_report_mode` to `single` if business users absolutely require one file for arbitrarily large results, with the understanding that one Spark task may become slow. The existing `spark.output_partitions` still determines the per-column staging shuffle; final per-column files remain exactly one per affected column.

## 4. Reproducibility and overwrites

- The run directory is **exclusively reserved** at startup. Reusing an existing `run_id` raises an error instead of replacing CSVs. Choose `--run_id AccumRC_v43_003` for the next run.
- `DataValidation_config_snapshot.json` records the input/configuration, code SHA-256 hashes, Spark/Python versions and input metadata (size/mtime for files). Hashes are **not** full dataset checksums.
- `_RUN_IN_PROGRESS.json` exists during execution. A successful execution publishes `DataValidation_run_manifest.json` last and removes the in-progress marker. If the CLI fails after reservation it attempts to create `_RUN_FAILED.json`.
- A validation data-check `FAIL` status can coexist with a `COMPLETED` manifest: the file generation succeeded, but the data validation did not pass.
- If a driver is abruptly killed, the marker may remain for recovery. Never silently reuse the old run ID.

## 5. Excel workbook

`DataValidation_summary.xlsx` contains **Overview**, **Columns**, **Patterns**, **Run Comparison**, and **Notes**. It includes aggregates, not millions of data rows. The `Patterns` tab can show common field values; if those must stay out of Excel, set `excel.include_pattern_values=false`. It is generated using Python standard library only, so installing `openpyxl`, `xlsxwriter` or pandas is unnecessary on Cloudera.

```json
"excel": {"enabled": true, "max_rows_per_sheet": 3000, "include_pattern_values": true}
```

## 6. Quiet terminal and debugging

The optional `--spark_log_level WARN` controls Spark messages after context startup, and `--conf spark.ui.showConsoleProgress=false` suppresses progress bars. Driver stderr and cluster startup INFO may still appear before the script changes Spark's log level; control those via cluster-compatible Log4j settings. Python errors and tracebacks are retained in the run logs. For production jobs on YARN, also preserve Spark/YARN logs.

## Tests and benchmarks

No-PySpark checks (Python 3):

```bash
python3 -m unittest discover -s tests -v
```

On a machine with PySpark, Java, and Spark 3 configured (these tests launch Spark locally):

```bash
python3 -m unittest discover -s tests -p 'test_v4_spark.py' -v
python3 -m unittest discover -s tests -p 'test_v43_spark.py' -v
python3 -m unittest discover -s tests -p 'test_v42_fixedwidth.py' -v
```

Benchmark using reproducible synthetic datasets, then examine per-stage timings and elapsed time:

```bash
spark3-submit --master 'local[2]' \
  --py-files data_validation_dashboard.py,data_validation_fixedwidth.py,data_validation_v43.py \
  benchmark_data_validation_v4.py --sizes 10000 100000 --columns 10 50 \
  --work-dir file:///home/svarma/tmp/dv-benchmark --repetitions 2
```

Add `--no-patterns --no-excel` to benchmark comparison/export without the new report overhead. The benchmark uses unique run IDs so reruns do not overwrite audit history.

**Verification status:** Python syntax, standard-library workbook compatibility, and no-Spark tests were checked in the release-building environment. Full Spark integration tests and performance timings require the actual Cloudera environment; don't infer production performance from offline tests.
