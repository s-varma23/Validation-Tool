# Version 4.3.0 — Release changes

Built from **V4.2.5** (not the original screenshot-based script). Main entry point remains `data_Validation_comp_v4.py`.

## Preserved

- Automatic PK detection still checks candidate columns in Non-Production order, stops at the **first non-null unique column in both inputs**, and does not continue scanning.
- Optional explicit composite keys, CSV/fixed-width TXT support, schema/mapping audits, NULL/date/numeric tolerance logic, reconciliation and malformed-record reports.
- Non-Production and Production labels; old CLI arguments `--bigplay_file` and `--daas_file`.
- Flat output layout: overall differences and missing rows at the run root; individual per-column CSVs directly in one `analysis/` directory, indexed by the existing report index.
- The combined report continues to show **only globally impacted columns**, not the full input schema.

## Added

1. **Patterns**: grouped counts of (`Column`, `Non-Production`, `Production`, `Difference_type`), most frequent Production value, and difference types. One `analysis/DataValidation_discrepancy_patterns.csv`; bounded top N values included in the dashboard/summary and Excel. Pattern observations are not verified root causes.
2. **Run-to-run comparisons**: optional `--compare_run <prior DataValidation_summary.json>` or `history.baseline_summary` generates `analysis/DataValidation_run_comparison.csv`, `DataValidation_run_comparison.json`, dashboard and workbook comparisons. Refuses incomparable keys/columns/input formats. Aggregate metric differences do not imply the same keys were fixed.
3. **CSV performance**: caches discrepancy detail for reuse. Small reports still generate a **single actual CSV**. When a root-level overall report exceeds the default 250,000 rows, adaptive mode writes several `__part_00000.csv` files **directly in the run root**, with no additional subfolders, and the dashboard links to all parts. Default 8 partitions, configurable; `export.large_report_mode=single` forces one file at potential performance cost. Per-column reports remain exactly one named CSV per impacted column.
4. **Reproducibility**: unique run-folder reservation, no silent overwrite, `DataValidation_config_snapshot.json` containing config/code hashes, runtime and source file metadata; `DataValidation_run_manifest.json` is written last, only on completed output. The CLI writes `_RUN_FAILED.json` on failure after reservation. This is a run-level audit, not a cryptographic proof of source dataset contents.
5. **Excel summary**: `DataValidation_summary.xlsx` with formatted Overview, Columns, Patterns, Run Comparison and Notes sheets. Aggregates only, no full record-level data; uses Python standard library (ZIP/OOXML), so no openpyxl/xlsxwriter installation is required on Cloudera. `excel.include_pattern_values=false` removes value patterns from the workbook when needed.
6. **Expanded tests**: additional offline unit tests and optional end-to-end Spark integration tests for patterns, history, xlsx, overwrite protection and multipart output.

## Notes / limitations

- Spark tests require an actual compatible Spark environment and are **not validated solely by syntax checks**.
- Single-file output bottlenecks are inherent to the user's flat CSV requirement; adaptive shards mitigate it above the threshold.
- Hadoop/Cloudera drivers must have write permissions for the configured output directory and local temp space for Excel copying; large object stores may have non-atomic rename behavior.
- Raw matched-record values and keys in HTML/CSV remain confidential; the workbook can include common source values in aggregated patterns.
- Status `FAIL` can still have a `COMPLETED` run manifest: completed means the job and exports finished, not that all data checks passed.
