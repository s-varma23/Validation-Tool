"""Spark integration scenarios; run on Cloudera with Python 3 + PySpark:
python -m unittest discover -s tests -p 'test_v43_spark.py' -v

Each case has independent temporary inputs and run IDs.
"""
import argparse
import importlib.util
import io
import json
import sys
import tempfile
import unittest
import zipfile
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
try:
    HAS_SPARK = importlib.util.find_spec('pyspark') is not None
except ValueError:
    HAS_SPARK = False
if HAS_SPARK:
    from pyspark.sql import SparkSession
    from pyspark.sql import functions as F
    import data_Validation_comp_v4 as tool
    import data_validation_v43 as extra


@unittest.skipUnless(HAS_SPARK, 'PySpark is required; run on the Cloudera Spark 3 server')
class V43SparkTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark = (SparkSession.builder.master('local[2]')
                     .appName('DataValidationV43Integration')
                     .config('spark.ui.enabled','false')
                     .config('spark.sql.shuffle.partitions','2')
                     .getOrCreate())
        cls.spark.sparkContext.setLogLevel('ERROR')

    @classmethod
    def tearDownClass(cls):
        cls.spark.stop()

    def config(self, home, runid='first', **changes):
        p = Path(home)
        x = p/'left.csv'; y=p/'right.csv'
        cfg = tool.configuration(argparse.Namespace(
            config=None,bigplay_file=str(x),daas_file=str(y),username=None,
            output_dir=str(p),run_id=runid,composite=None,numeric_tolerance=None))
        cfg['infer_schema'] = False
        cfg['numeric_columns']=['AMOUNT']
        cfg['rules']={'AMOUNT': {'numeric': True, 'tolerance': '0'}}
        cfg.update(changes)
        return cfg

    def test_pattern_top_production_default_and_pair(self):
        frame = self.spark.createDataFrame(
            [('DELAY','4','1','NUMERIC_DIFFERENCE'),
             ('DELAY','4','1','NUMERIC_DIFFERENCE'),
             ('DELAY','5','1','NUMERIC_DIFFERENCE'),
             ('DELAY','6','2','NUMERIC_DIFFERENCE')],
            ['Column_affected','Non-Production','Production','Difference_type'])
        grouped=extra.top_patterns_frame(frame, 2)
        target=grouped.where("Pattern_type = 'PRODUCTION_VALUE' AND Production = '1'").first()
        self.assertEqual(target['Occurrences'], 3)
        pair=grouped.where("Pattern_type = 'VALUE_PAIR' AND `Non-Production` = '4'").first()
        self.assertEqual(pair['Occurrences'], 2)

    def test_full_pipeline_patterns_excel_manifest(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            (p/'left.csv').write_text('ID,AMOUNT,STATUS\n001,10,Active\n002,15,Active\n003,20,Active\n004,40,Active\n')
            (p/'right.csv').write_text('ID,AMOUNT,STATUS\n001,1,Active\n002,1,Active\n003,1,Active\n004,40,Active\n')
            cfg=self.config(d)
            result=tool.run(self.spark,cfg)
            root=p/'DataValidation_v4'/'first'
            self.assertEqual(result['mismatched_records'],3)
            self.assertEqual(result['column_report_count'],1)
            self.assertTrue((root/'analysis'/extra.PATTERN_CSV).is_file())
            self.assertTrue((root/extra.EXCEL_FILE).is_file())
            self.assertTrue((root/extra.CONFIG_FILE).is_file())
            self.assertTrue((root/extra.MANIFEST_FILE).is_file())
            self.assertFalse((root/extra.IN_PROGRESS).exists())
            self.assertEqual(json.loads((root/extra.MANIFEST_FILE).read_text())['state'],'COMPLETED')
            with zipfile.ZipFile(root/extra.EXCEL_FILE) as workbook:
                self.assertIsNone(workbook.testzip())
                self.assertIn('xl/worksheets/sheet3.xml',workbook.namelist())
            self.assertTrue(any(x['Pattern_type']=='PRODUCTION_VALUE' and x['Occurrences']==3 and x['Production']=='1'
                                for x in result['discrepancy_patterns']))
            self.assertIn('Recurring discrepancy patterns', (root/tool.DASHBOARD_FILE).read_text())
            self.assertEqual(self.spark.read.option('header', True).csv(str(root/tool.WIDE_OUTPUT)).count(),3)

    def test_baseline_comparison_and_refuse_run_id_reuse(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            (p/'left.csv').write_text('ID,AMOUNT,STATUS\n001,10,Active\n002,20,Active\n003,30,Active\n')
            right=p/'right.csv'
            right.write_text('ID,AMOUNT,STATUS\n001,15,Active\n002,25,Active\n003,30,Active\n')
            first=self.config(d,runid='baseline')
            old=tool.run(self.spark,first)
            baseline=p/'DataValidation_v4'/'baseline'/tool.SUMMARY_FILE
            with self.assertRaisesRegex(FileExistsError,'Refusing to overwrite'):
                tool.run(self.spark,first)
            self.assertEqual(json.loads(baseline.read_text())['mismatched_records'],2)
            right.write_text('ID,AMOUNT,STATUS\n001,10,Active\n002,20,Active\n003,30,Active\n')
            nextcfg=self.config(d,runid='updated')
            nextcfg['history']={**nextcfg['history'],'baseline_summary':str(baseline)}
            newer=tool.run(self.spark,nextcfg)
            self.assertEqual(newer['mismatched_records'],0)
            self.assertEqual(next(x for x in newer['run_comparison']['metrics'] if x['Metric']=='mismatched_records')['Delta'],-2)
            self.assertTrue((p/'DataValidation_v4'/'updated'/'analysis'/extra.HISTORY_CSV).exists())
            self.assertIn('Comparison with previous run',
                          (p/'DataValidation_v4'/'updated'/tool.DASHBOARD_FILE).read_text())
            self.assertEqual(old['mismatched_records'],2)

    def test_adaptive_shards_are_flat_root_csv_files(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            (p/'left.csv').write_text('ID,AMOUNT\n'+''.join(f'{i:05d},10\n' for i in range(14)))
            (p/'right.csv').write_text('ID,AMOUNT\n'+''.join(f'{i:05d},11\n' for i in range(14)))
            cfg=self.config(d,runid='multipart')
            cfg['export']={**cfg['export'], 'large_report_threshold_rows':5,
                           'large_report_partitions':3}
            result=tool.run(self.spark,cfg)
            root=p/'DataValidation_v4'/'multipart'
            self.assertEqual(result['mismatched_records'],14)
            self.assertFalse(result['combined_csv_single_file'])
            self.assertFalse((root/tool.WIDE_OUTPUT).exists())
            self.assertEqual(len(result['combined_output_files']),3)
            self.assertEqual(sum(self.spark.read.option('header',True).csv(
                str(root/n)).count() for n in result['combined_output_files']),14)
            self.assertEqual(len(list((root/'analysis').glob('Column_*_differences.csv'))),1)
            self.assertIn(result['combined_output_files'][0],(root/tool.DASHBOARD_FILE).read_text())

    def test_history_key_mismatch_cannot_mark_complete(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)
            (p/'left.csv').write_text('ID,AMOUNT\nA,1\nB,2\n')
            (p/'right.csv').write_text('ID,AMOUNT\nA,2\nB,3\n')
            wrong={ 'run_id':'wrong','primary_key_columns':['NOT_ID'],
                    'columns_compared':['AMOUNT'],'input_formats':{'File1':'csv','File2':'csv'}}
            previous=p/'wrong.json';previous.write_text(json.dumps(wrong))
            cfg=self.config(d,runid='incompatible')
            cfg['history']={'baseline_summary':str(previous)}
            with self.assertRaisesRegex(ValueError,'different PK'):
                tool.run(self.spark,cfg)
            self.assertFalse((p/'DataValidation_v4'/'incompatible'/extra.MANIFEST_FILE).exists())


if __name__=='__main__':
    unittest.main(verbosity=2)
