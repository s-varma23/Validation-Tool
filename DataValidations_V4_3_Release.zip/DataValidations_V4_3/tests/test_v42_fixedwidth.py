"""Fixed-width support tests. Unit tests run without Spark; integration tests need real PySpark."""
import argparse
import importlib.util
import json
import sys
import tempfile
import types
import unittest
from decimal import Decimal
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(ROOT))
try:
    HAS_SPARK = importlib.util.find_spec('pyspark') is not None
except ValueError:
    HAS_SPARK = False
if not HAS_SPARK and 'pyspark' not in sys.modules:
    pkg=types.ModuleType('pyspark');pkg.StorageLevel=types.SimpleNamespace(MEMORY_AND_DISK='test')
    sql=types.ModuleType('pyspark.sql');sql.functions=types.ModuleType('pyspark.sql.functions')
    sql.SparkSession=object
    dt=types.ModuleType('pyspark.sql.types');dt.NumericType=type('NumericType',(),{})
    sys.modules.update({'pyspark':pkg,'pyspark.sql':sql,
                        'pyspark.sql.functions':sql.functions,'pyspark.sql.types':dt})
from data_validation_fixedwidth import validate_layout
import data_Validation_comp_v4 as tool
if HAS_SPARK:
    from pyspark.sql import SparkSession, functions as F


def layout(mode='fail'):
    return {'format':'fixed_width', 'record_length':39, 'on_malformed':mode,
            'fields':[{'name':'Policy Number','start':1,'length':8},
                      {'name':'Customer Name','start':9,'length':14},
                      {'name':'Premium','start':23,'length':9,'type':'decimal',
                       'precision':15,'scale':2,'implied_decimals':2},
                      {'name':'Status','start':32,'length':8}]}


def sample_line(key,name,cents,status):
    return f'{key:<8}{name:<14}{cents:09d}{status:<8}'


def config_for(folder, path1, path2, name='fixed'):
    a=argparse.Namespace(config=None,bigplay_file=str(path1),daas_file=str(path2),
                         username=None,output_dir=str(folder),composite=None,
                         run_id=name,numeric_tolerance=None)
    return tool.configuration(a)


class LayoutTests(unittest.TestCase):
    def test_valid_layout_and_length(self):
        fields, width = validate_layout(layout(), 'File1')
        self.assertEqual(width,39)
        self.assertEqual(len(fields),4)
        self.assertEqual(fields[0]['start'],1)

    def test_overlapping_ranges_rejected(self):
        l=layout();l['fields'][1]['start']=7
        with self.assertRaisesRegex(ValueError,'overlap'):validate_layout(l,'File1')

    def test_noninteger_position_rejected(self):
        l=layout();l['fields'][0]['start']='1'
        with self.assertRaisesRegex(ValueError,'positive integers'):validate_layout(l,'File1')

    def test_duplicate_normalized_field_rejected(self):
        l=layout();l['fields'][1]['name']='policy_number'
        with self.assertRaisesRegex(ValueError,'duplicate'):validate_layout(l,'File1')

    def test_too_short_length_rejected(self):
        l=layout();l['record_length']=32
        with self.assertRaisesRegex(ValueError,'record_length'):validate_layout(l,'File1')

    def test_implied_decimal_with_short_scale_rejected(self):
        l=layout();l['fields'][2]['scale']=1
        with self.assertRaisesRegex(ValueError,'scale'):validate_layout(l,'File1')

    def test_column_layout_from_json_and_csv_compat(self):
        with tempfile.TemporaryDirectory() as d:
            p=Path(d)/'fixed.json'
            p.write_text(json.dumps({'inputs':{'File1':layout()},
                                     'bigplay_file':'f1.txt','daas_file':'f2.csv',
                                     'output_dir':d}),encoding='utf-8')
            a=argparse.Namespace(config=str(p),bigplay_file=None,daas_file=None,
                                 username=None,output_dir=None,composite=None,
                                 run_id='try1',numeric_tolerance=None)
            cfg=tool.configuration(a)
            self.assertEqual(cfg['inputs']['File1']['format'],'fixed_width')
            self.assertEqual(cfg['inputs']['File2']['format'],'csv')


@unittest.skipUnless(HAS_SPARK,'Needs PySpark and working Java')
class SparkFixedWidthTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.spark=(SparkSession.builder.master('local[2]').appName('DataValidationsV42Tests')
                   .config('spark.ui.enabled','false').config('spark.sql.shuffle.partitions','2')
                   .getOrCreate())
        cls.spark.conf.set('spark.sql.ansi.enabled','false')
        cls.spark.sparkContext.setLogLevel('ERROR')

    @classmethod
    def tearDownClass(cls):cls.spark.stop()

    def test_read_decimal_and_trim_and_preserve_leading_zero(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'x.txt';f.write_text(sample_line('00000001','Jane',125050,'ACTIVE')+'\n')
            cfg={**tool.DEFAULTS,'inputs':{'File1':layout(),'File2':{'format':'csv'}}}
            df,issues,audit,meta=tool.load_data(self.spark,str(f),cfg,'File1',return_meta=True)
            row=df.first()
            self.assertEqual(row['Policy_Number'],'00000001')
            self.assertEqual(row['Customer_Name'],'Jane')
            self.assertEqual(Decimal(str(row['Premium'])),Decimal('1250.50'))
            self.assertEqual(issues,[])
            self.assertEqual(meta['malformed_rows'],0)
            self.assertEqual(audit[0]['Change_type'],'HEADER_NORMALIZED')

    def test_full_fixed_width_vs_csv_pipeline(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/'file1.txt';b=Path(d)/'file2.csv'
            a.write_text(sample_line('00000001','Jane',125050,'ACTIVE')+'\n'
                         +sample_line('00000002','John',98025,'ACTIVE')+'\n')
            b.write_text('Policy_Number,Customer_Name,Premium,Status\n'
                         '00000001,Jane,1250.50,ACTIVE\n'
                         '00000002,John,1000.25,ACTIVE\n')
            cfg=config_for(d,a,b,'mixed')
            cfg.update({'inputs':{'File1':layout(),'File2':{'format':'csv'}},
                        'infer_schema':False,'column_types':{'Premium':'decimal(15,2)'},
                        'numeric_columns':['Premium']})
            result=tool.run(self.spark,cfg)
            self.assertEqual(result['primary_key'],'Policy_Number')
            self.assertEqual(result['mismatched_records'],1)
            self.assertEqual(result['missing_rows'],0)
            self.assertEqual(result['schema_difference_count'],0)
            self.assertEqual(result['malformed_rows'],0)
            path=Path(d)/'DataValidation_v4'/'mixed'
            self.assertTrue((path/tool.DASHBOARD_FILE).is_file())
            rows=self.spark.read.option('header',True).csv(str(path/tool.ANALYSIS_FOLDER/tool.per_column_csv_name('Premium'))).collect()
            self.assertEqual([(r['PK'],r['Column_affected']) for r in rows],
                             [('00000002','Premium')])

    def test_short_record_saved_and_fails_in_fail_and_report_modes(self):
        with tempfile.TemporaryDirectory() as d:
            a=Path(d)/'file1.txt';b=Path(d)/'file2.csv'
            a.write_text(sample_line('00000001','Jane',125050,'ACTIVE')+'\nSHORT\n')
            b.write_text('Policy_Number,Customer_Name,Premium,Status\n'
                         '00000001,Jane,1250.50,ACTIVE\n')
            cfg=config_for(d,a,b,'fail_mode')
            cfg.update({'inputs':{'File1':layout('fail'),'File2':{'format':'csv'}},
                        'infer_schema':False,'column_types':{'Premium':'decimal(15,2)'},
                        'numeric_columns':['Premium']})
            with self.assertRaisesRegex(ValueError,'malformed fixed-width'):
                tool.run(self.spark,cfg)
            f=Path(d)/'DataValidation_v4'/'fail_mode'/tool.ANALYSIS_FOLDER/tool.MALFORMED_FILE1
            self.assertEqual(self.spark.read.option('header',True).csv(str(f)).count(),1)
            cfg['inputs']['File1']['on_malformed']='report'
            cfg['run_dir']=str(Path(d)/'DataValidation_v4'/'report_mode')
            r=tool.run(self.spark,cfg)
            self.assertEqual(r['status'],'FAIL')
            self.assertEqual(r['malformed_rows'],1)
            self.assertEqual(r['file1_rows'],1)

    def test_invalid_decimal_conversions(self):
        with tempfile.TemporaryDirectory() as d:
            f=Path(d)/'x.txt'
            f.write_text(sample_line('00000001','Jane',125050,'ACTIVE')+'\n'
                         +f'{"00000002":<8}{"John":<14}{"NOTANUMBR":<9}{"ACTIVE":<8}'+'\n')
            cfg={**tool.DEFAULTS,'inputs':{'File1':layout(),'File2':{'format':'csv'}}}
            df,err,_,meta=tool.load_data(self.spark,str(f),cfg,'File1',return_meta=True)
            self.assertEqual(err,[('Premium',1,'INVALID_FIXED_WIDTH_TYPE')])
            self.assertEqual(meta['malformed_rows'],0)
            self.assertIsNone(df.where(F.col('Policy_Number')=='00000002').first()['Premium'])


if __name__=='__main__':
    unittest.main()
