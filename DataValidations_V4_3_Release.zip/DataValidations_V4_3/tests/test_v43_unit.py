"""V4.3 unit tests: run with python -m unittest discover -s tests -v."""
import argparse
import io
import json
import sys
import tempfile
import unittest
import xml.etree.ElementTree as ET
import zipfile
from pathlib import Path
from unittest.mock import patch

ROOT = Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
# Existing offline tests provide lightweight PySpark import stubs if unavailable.
try:
    import pyspark
except ImportError:
    import types
    pkg = types.ModuleType('pyspark')
    pkg.StorageLevel = types.SimpleNamespace(MEMORY_AND_DISK='test')
    sql = types.ModuleType('pyspark.sql')
    sql.functions = types.ModuleType('pyspark.sql.functions')
    sql.SparkSession = object
    dt = types.ModuleType('pyspark.sql.types')
    dt.NumericType = type('NumericType', (), {})
    sys.modules.update({'pyspark': pkg, 'pyspark.sql': sql,
                        'pyspark.sql.functions': sql.functions, 'pyspark.sql.types': dt})
import data_Validation_comp_v4 as tool
import data_validation_v43 as add
from data_validation_dashboard import render_dashboard


def current(**kw):
    return {'run_id': 'new', 'primary_key': 'ID', 'primary_key_columns': ['ID'],
            'columns_compared': ['Amount', 'Status'], 'input_formats': {'File1': 'csv', 'File2': 'csv'},
            'file1_rows': 10, 'file2_rows': 10, 'matched_keys': 10, 'mismatched_records': 3,
            'missing_rows': 0, 'schema_difference_count': 0, 'invalid_conversions': 0,
            'reconciliation_failures': 0,
            'column_mismatch_summary': [{'Column_affected': 'Amount', 'Mismatch_rows': 3}], **kw}


class V43Tests(unittest.TestCase):
    def test_backward_compatible_defaults_and_explicit_mode(self):
        args = argparse.Namespace(config=None, bigplay_file='left.csv', daas_file='right.csv',
                                  output_dir='/tmp/toolv43', username=None, run_id='check',
                                  composite=None, numeric_tolerance=None, compare_run=None)
        config = tool.configuration(args)
        self.assertEqual(config['run_id'], 'check')
        self.assertEqual(config['export']['large_report_mode'], 'adaptive')
        self.assertTrue(config['excel']['enabled'])
        self.assertEqual(config['patterns']['top_per_column'], 6)
        with tempfile.TemporaryDirectory() as d:
            p = Path(d) / 'cfg.json'
            p.write_text(json.dumps({'export': {'large_report_mode': 'single'},
                                     'history': {'baseline_summary': '/tmp/previous.json'}}))
            args.config = str(p)
            cfg = tool.configuration(args)
            self.assertEqual(cfg['history']['baseline_summary'], '/tmp/previous.json')
            self.assertEqual(cfg['export']['large_report_mode'], 'single')

    def test_config_rejects_invalid_new_sections(self):
        args = argparse.Namespace(config=None, bigplay_file='a', daas_file='b', output_dir='/tmp',
                                  username=None, run_id='go', composite=None, numeric_tolerance=None)
        for settings in [{'patterns': {'top_per_column': 0}},
                         {'export': {'large_report_mode': 'skip'}},
                         {'export': {'large_report_partitions': 0}},
                         {'excel': {'max_rows_per_sheet': 1}},
                         {'history': {'baseline_summary': 42}},
                         {'patterns': {'unrecognized': True}}]:
            with self.subTest(settings=settings), tempfile.TemporaryDirectory() as d:
                p = Path(d) / 'config.json'
                p.write_text(json.dumps(settings))
                args.config = str(p)
                with self.assertRaises(ValueError):
                    tool.configuration(args)

    def test_run_trends_and_column_changes(self):
        old = current(run_id='old', mismatched_records=5,
                      column_mismatch_summary=[{'Column_affected': 'Amount', 'Mismatch_rows': 4},
                                               {'Column_affected': 'Status', 'Mismatch_rows': 1}])
        new = current(run_id='new', mismatched_records=3,
                      column_mismatch_summary=[{'Column_affected': 'Amount', 'Mismatch_rows': 3},
                                               {'Column_affected': 'Currency', 'Mismatch_rows': 1}])
        # Currency must be part of a compatible comparison schema first.
        old['columns_compared'].append('Currency'); new['columns_compared'].append('Currency')
        h = add.summarize_history(new, old)
        self.assertEqual(next(x for x in h['metrics'] if x['Metric'] == 'mismatched_records')['Delta'], -2)
        by_col = {x['Column']: x['Change'] for x in h['columns']}
        self.assertEqual(by_col['Status'], 'NO_LONGER_AFFECTED')
        self.assertEqual(by_col['Currency'], 'NEWLY_AFFECTED')
        self.assertIn('same affected records', h['disclaimer'])

    def test_incompatible_baseline_is_rejected(self):
        old = current()
        for key, value in [('primary_key_columns', ['OTHER']),
                           ('columns_compared', ['Amount']),
                           ('input_formats', {'File1': 'fixed_width', 'File2': 'csv'})]:
            newer = current(**{key: value})
            with self.subTest(key=key), self.assertRaises(ValueError):
                add.summarize_history(newer, old)

    def test_workbook_is_real_xlsx_and_safe_from_excel_formula_injection(self):
        summary = {**current(), 'status': 'REVIEW', 'run_dir': 'file:///tmp/new',
                   'pk_strategy': 'first unique', 'column_report_files': {'Amount': 'analysis/Column_Amount_differences.csv'}}
        patterns = [{'Column_affected': 'Amount', 'Pattern_type': 'PRODUCTION_VALUE',
                     'Non-Production': None, 'Production': '=HYPERLINK("http://bad")',
                     'Difference_type': 'ALL_TYPES', 'Occurrences': 3}]
        workbook = add.make_summary_xlsx(summary, patterns, None)
        with zipfile.ZipFile(io.BytesIO(workbook)) as z:
            self.assertIsNone(z.testzip())
            sheet_names = [n for n in z.namelist() if n.startswith('xl/worksheets/sheet')]
            self.assertEqual(len(sheet_names), 5)
            for name in sheet_names:
                ET.fromstring(z.read(name))
            pattern_xml = z.read('xl/worksheets/sheet3.xml').decode('utf-8')
            self.assertNotIn('<f>', pattern_xml)
            self.assertIn('&apos;=HYPERLINK', pattern_xml)
            self.assertIn('Non-Production', pattern_xml)
            self.assertIn('Production', pattern_xml)

    def test_no_raw_csv_records_in_summary_workbook(self):
        summary = {**current(), 'status': 'REVIEW', 'run_dir': 'file:///tmp/new',
                   'column_report_files': {}, 'pk_strategy': 'first unique'}
        archive = add.make_summary_xlsx(summary, [], None)
        self.assertNotIn(b'SECRET-POLICY-ID', archive)
        with zipfile.ZipFile(io.BytesIO(archive)) as z:
            self.assertEqual(len([x for x in z.namelist() if 'sheet' in x and x.endswith('.xml')]), 5)

    def test_config_hash_is_order_independent(self):
        self.assertEqual(add.stable_hash({'a': 1, 'b': 2}), add.stable_hash({'b': 2, 'a': 1}))
        self.assertNotEqual(add.stable_hash({'a': 1}), add.stable_hash({'a': 2}))

    def test_dashboard_links_and_escapes_new_sections(self):
        summary = {**current(), 'status': 'REVIEW', 'version': '4.3.0',
                   'run_dir': 'file:///tmp/abc', 'report_layout': 'flat',
                   'discrepancy_patterns': [{'Column_affected': '<script>bad</script>',
                                             'Pattern_type': 'PRODUCTION_VALUE',
                                             'Non-Production': '4', 'Production': '1',
                                             'Difference_type': 'ALL_TYPES', 'Occurrences': 5}],
                   'column_report_files': {}, 'column_mismatch_summary': [],
                   'run_comparison': add.summarize_history(current(), current(run_id='before')),
                   'combined_output_files': ['DataValidation_differencesall_records__part_00000.csv',
                                             'DataValidation_differencesall_records__part_00001.csv'],
                   'missing_output_files': ['DataValidation_differencesmissing_records.csv'],
                   'pattern_report_file': 'analysis/DataValidation_discrepancy_patterns.csv'}
        page = render_dashboard(summary, [])
        self.assertIn('Recurring discrepancy patterns', page)
        self.assertIn('Comparison with previous run', page)
        self.assertIn('DataValidation_summary.xlsx', page)
        self.assertIn('DataValidation_differencesall_records__part_00001.csv', page)
        self.assertIn('&lt;script&gt;bad&lt;/script&gt;', page)
        self.assertNotIn('<script>bad</script>', page)

    def test_data_hygiene_for_path_identifiers(self):
        self.assertEqual(add.safe_run_ref('Run-1_2026.10'), 'Run-1_2026.10')
        with self.assertRaises(ValueError):
            add.safe_run_ref('../escape')


if __name__ == '__main__':
    unittest.main()
