#!/usr/bin/env python3
"""V4.3 insights, reproducibility, and portable XLSX helpers.

Standard-library helpers work on the Cloudera driver without pandas/openpyxl.
Spark-specific functions import PySpark inside their bodies to support offline tests.
"""
import hashlib
import io
import json
import math
import os
import platform
import re
import sys
import tempfile
import zipfile
from datetime import datetime, timezone
from pathlib import Path
from xml.sax.saxutils import escape

VERSION = '4.3.0'
PATTERN_CSV = 'DataValidation_discrepancy_patterns.csv'
HISTORY_CSV = 'DataValidation_run_comparison.csv'
HISTORY_JSON = 'DataValidation_run_comparison.json'
EXCEL_FILE = 'DataValidation_summary.xlsx'
CONFIG_FILE = 'DataValidation_config_snapshot.json'
MANIFEST_FILE = 'DataValidation_run_manifest.json'
IN_PROGRESS = '_RUN_IN_PROGRESS.json'
FAILED_FILE = '_RUN_FAILED.json'


def utc_now():
    return datetime.now(timezone.utc).isoformat()


def stable_hash(value):
    return hashlib.sha256(json.dumps(value, sort_keys=True, ensure_ascii=False,
                                     separators=(',', ':'), default=str).encode('utf-8')).hexdigest()


def safe_run_ref(text):
    if not isinstance(text, str) or not re.fullmatch(r'[A-Za-z0-9_.-]+', text):
        raise ValueError('Run reference must contain only letters, numbers, underscore, dot or hyphen.')
    return text


def fs_path(spark, value):
    jpath = spark._jvm.org.apache.hadoop.fs.Path(str(value))
    return jpath.getFileSystem(spark._jsc.hadoopConfiguration()), jpath


def reserve_run(spark, root, run_id):
    """Exclusive Hadoop FS create avoids overwrites (including competing drivers)."""
    fs, p = fs_path(spark, root)
    if fs.exists(p):
        raise FileExistsError(f'Refusing to overwrite existing run directory: {root}. Use a new --run_id.')
    if not fs.mkdirs(p) and not fs.exists(p):
        raise OSError(f'Failed to create run directory: {root}')
    marker = spark._jvm.org.apache.hadoop.fs.Path(p, IN_PROGRESS)
    # create(path, False) is exclusive even if a competing process mkdirs(root).
    stream = fs.create(marker, False)
    try:
        payload = json.dumps({'run_id': run_id, 'started_utc': utc_now(), 'state': 'IN_PROGRESS'})
        writer = spark._jvm.java.io.OutputStreamWriter(stream, 'UTF-8')
        try:
            writer.write(payload)
            writer.flush()
        finally:
            writer.close()
    except Exception:
        try:
            stream.close()
        except Exception:
            pass
        raise
    return root.rstrip('/') + '/' + IN_PROGRESS


def finish_run(spark, root, write_text, manifest, ok=True):
    """Publish last, after all reports have been written and checked."""
    fs, p = fs_path(spark, root)
    target = MANIFEST_FILE if ok else FAILED_FILE
    manifest = {**manifest, 'completed_utc': utc_now(), 'state': 'COMPLETED' if ok else 'FAILED'}
    write_text(spark, root.rstrip('/') + '/' + target,
               json.dumps(manifest, indent=2, ensure_ascii=False, default=str) + '\n')
    marker = spark._jvm.org.apache.hadoop.fs.Path(p, IN_PROGRESS)
    if fs.exists(marker):
        fs.delete(marker, False)
    return target


def list_report_files(spark, root, cap=10000):
    """Collect file *metadata*, never row-level data."""
    fs, top = fs_path(spark, root)
    results = []
    stack = [top]
    while stack:
        current = stack.pop()
        for item in fs.listStatus(current):
            p = item.getPath()
            if item.isDirectory():
                stack.append(p)
                continue
            name = p.getName()
            if name.startswith('.__') or name.startswith('.') or name.startswith('_'):
                continue
            uri = str(p.toUri())
            relative = uri[len(str(top.toUri()).rstrip('/')):].lstrip('/')
            results.append({'file': relative, 'bytes': int(item.getLen())})
            if len(results) > cap:
                raise ValueError('Too many output files to enumerate in manifest; inspect export partitioning.')
    return sorted(results, key=lambda r: r['file'])


def source_metadata(spark, path):
    fs, p = fs_path(spark, path)
    if not fs.exists(p):
        return {'path': path, 'exists': False}
    status = fs.getFileStatus(p)
    return {'path': path, 'exists': True, 'is_directory': bool(status.isDirectory()),
            'bytes': int(status.getLen()), 'modified_epoch_ms': int(status.getModificationTime())}


def reproducibility_snapshot(spark, cfg, modules):
    """Record configuration and source-code hashes without credentials or raw data."""
    digest = {}
    for name, path in modules.items():
        try:
            digest[name] = hashlib.sha256(Path(path).read_bytes()).hexdigest()
        except (OSError, TypeError):
            digest[name] = None
    excluded = {'log_file', 'error_log_file', '_reserved', '_logging_ready', 'run_dir', 'username'}
    settings = {k: v for k, v in cfg.items() if k not in excluded and not k.startswith('_')}
    return {'tool_version': VERSION, 'captured_utc': utc_now(), 'run_id': cfg['run_id'],
            'settings': settings, 'settings_sha256': stable_hash(settings),
            'code_sha256': digest,
            'spark_version': spark.version, 'python_version': sys.version.split()[0],
            'platform': platform.platform(),
            'inputs_metadata': {'Non-Production': source_metadata(spark, cfg['bigplay_file']),
                                'Production': source_metadata(spark, cfg['daas_file'])},
            'spark_runtime': {'master': spark.sparkContext.master,
                              'shuffle_partitions': spark.conf.get('spark.sql.shuffle.partitions')}}


def summarize_history(current, previous):
    """Compare aggregate run summaries; does NOT claim the same PKs were resolved."""
    if previous.get('primary_key_columns') != current.get('primary_key_columns'):
        raise ValueError('Baseline uses different PK columns; cannot compare runs safely.')
    if set(previous.get('columns_compared', [])) != set(current.get('columns_compared', [])):
        raise ValueError('Baseline compared different columns; choose a compatible baseline.')
    if previous.get('input_formats') != current.get('input_formats'):
        raise ValueError('Baseline input formats differ; cannot compare runs safely.')
    metrics = ('file1_rows', 'file2_rows', 'matched_keys', 'mismatched_records',
               'missing_rows', 'schema_difference_count', 'invalid_conversions',
               'reconciliation_failures')
    changes = []
    for name in metrics:
        old, new = int(previous.get(name, 0)), int(current.get(name, 0))
        changes.append({'Metric': name, 'Previous': old, 'Current': new, 'Delta': new - old})
    prior_cols = {str(row['Column_affected']): int(row['Mismatch_rows'])
                  for row in previous.get('column_mismatch_summary', [])}
    current_cols = {str(row['Column_affected']): int(row['Mismatch_rows'])
                    for row in current.get('column_mismatch_summary', [])}
    per_column = []
    for col in sorted(set(prior_cols) | set(current_cols)):
        before, after = prior_cols.get(col, 0), current_cols.get(col, 0)
        state = ('NEWLY_AFFECTED' if before == 0 and after else
                 'NO_LONGER_AFFECTED' if after == 0 and before else
                 'INCREASED' if after > before else 'DECREASED' if after < before else 'UNCHANGED')
        per_column.append({'Column': col, 'Previous': before, 'Current': after,
                           'Delta': after - before, 'Change': state})
    return {'baseline_run': previous.get('run_id', previous.get('run_dir', 'unknown')),
            'baseline_status': previous.get('status'),
            'current_status': current.get('status'),
            'metrics': changes, 'columns': per_column,
            'disclaimer': ('Run-level count changes do not identify the same affected records. '
                           'Use matched-key comparisons for record-level resolution claims.')}


def top_patterns_frame(detail, top_per_column=8):
    """Spark aggregation only: produces frequent value pairs and target defaults.

    Bounded collection is performed separately. No .collect() on raw details.
    """
    from pyspark.sql import functions as F, Window
    group_names = ['Column_affected', 'Pattern_type', 'Non-Production', 'Production', 'Difference_type']
    pairs = (detail.groupBy('Column_affected', 'Non-Production', 'Production', 'Difference_type')
             .count().withColumn('Pattern_type', F.lit('VALUE_PAIR'))
             .select(*group_names, F.col('count').cast('long').alias('Occurrences')))
    targets = (detail.groupBy('Column_affected', 'Production').count()
               .withColumn('Pattern_type', F.lit('PRODUCTION_VALUE'))
               .withColumn('Non-Production', F.lit(None).cast('string'))
               .withColumn('Difference_type', F.lit('ALL_TYPES'))
               .select(*group_names, F.col('count').cast('long').alias('Occurrences')))
    types = (detail.groupBy('Column_affected', 'Difference_type').count()
             .withColumn('Pattern_type', F.lit('DIFFERENCE_TYPE'))
             .withColumn('Non-Production', F.lit(None).cast('string'))
             .withColumn('Production', F.lit(None).cast('string'))
             .select(*group_names, F.col('count').cast('long').alias('Occurrences')))
    all_patterns = pairs.unionByName(targets).unionByName(types)
    rank = Window.partitionBy('Column_affected', 'Pattern_type').orderBy(
        F.desc('Occurrences'), F.asc_nulls_last('Production'), F.asc_nulls_last('Non-Production'))
    return all_patterns.withColumn('_r', F.row_number().over(rank)).where(
        F.col('_r') <= int(top_per_column)).drop('_r')


def select_bounded_patterns(frame, max_rows):
    return [r.asDict() for r in frame.orderBy(F.desc('Occurrences'),
                                            'Column_affected', 'Pattern_type')
            .limit(int(max_rows)).collect()]


# Portable, dependency-free, bounded OOXML workbook writer. Avoids installing
# packages in a locked-down Cloudera environment, exports only aggregated rows.
def _xlsx_cell_ref(row, column):
    result = ''
    while column:
        column, digit = divmod(column - 1, 26)
        result = chr(65 + digit) + result
    return f'{result}{row}'


def _xlsx_cell(value, row, col, header=False):
    ref = _xlsx_cell_ref(row, col)
    style = ' s="1"' if header else ''
    if isinstance(value, (int, float)) and not isinstance(value, bool) and math.isfinite(value):
        return f'<c r="{ref}"{style}><v>{value}</v></c>'
    if value is None:
        value = ''
    value = str(value)[:32767]
    if value.lstrip().startswith(('=', '+', '-', '@')):
        value = "'" + value  # additional spreadsheet formula-injection protection
    value = ''.join(ch for ch in value if (ord(ch) in (9, 10, 13) or 32 <= ord(ch) <= 0xD7FF or 0xE000 <= ord(ch) <= 0xFFFD or 0x10000 <= ord(ch) <= 0x10FFFF))
    safe = escape(value, {'"': '&quot;', "'": '&apos;'})
    return f'<c r="{ref}" t="inlineStr"{style}><is><t xml:space="preserve">{safe}</t></is></c>'


def make_summary_xlsx(summary, patterns, history, max_rows=3000):
    """Create an Excel-readable .xlsx ZIP stream, without external libraries.

    No raw record-level values are included. Patterns expose aggregated values,
    so user can disable patterns when distribution values are sensitive.
    """
    overview = [
        ('Metric', 'Value'), ('Tool version', VERSION), ('Status', summary.get('status')),
        ('Run ID', summary.get('run_id')), ('Primary key', summary.get('primary_key')),
        ('Non-Production rows', summary.get('file1_rows')),
        ('Production rows', summary.get('file2_rows')),
        ('Matched keys', summary.get('matched_keys')),
        ('Mismatched records', summary.get('mismatched_records')),
        ('Missing records', summary.get('missing_rows')),
        ('Reconciliation failures', summary.get('reconciliation_failures')),
        ('Output location', summary.get('run_dir')),
        ('Report generated UTC', utc_now()),
    ]
    columns = [('Column', 'Mismatch rows', 'NULL mismatches', 'Mismatch %', 'Max absolute difference', 'CSV path')]
    for r in sorted(summary.get('column_mismatch_summary', []),
                    key=lambda x: -int(x.get('Mismatch_rows', 0)))[:max_rows-1]:
        columns.append((r.get('Column_affected'), int(r.get('Mismatch_rows') or 0),
                        int(r.get('Null_mismatch_rows') or 0),
                        float(r.get('Mismatch_pct_of_matched') or 0),
                        str(r.get('Max_absolute_difference') or ''),
                        summary.get('column_report_files', {}).get(r.get('Column_affected'), '')))
    patterns_sheet = [('Column', 'Pattern type', 'Non-Production', 'Production', 'Difference type', 'Occurrences')]
    for r in patterns[:max_rows-1]:
        patterns_sheet.append((r.get('Column_affected'), r.get('Pattern_type'),
                               r.get('Non-Production'), r.get('Production'),
                               r.get('Difference_type'), int(r.get('Occurrences') or 0)))
    comparisons = [('Scope', 'Item', 'Previous', 'Current', 'Delta', 'Change')]
    if history:
        comparisons.extend(('Overall', x['Metric'], x['Previous'], x['Current'], x['Delta'], '')
                           for x in history['metrics'])
        comparisons.extend(('Column', x['Column'], x['Previous'], x['Current'], x['Delta'], x['Change'])
                           for x in history['columns'][:max_rows])
    notes = [('Item', 'Detail'), ('Interpretation', 'Counts are summaries, not record-level proof of resolution'),
             ('PK policy', summary.get('pk_strategy', '')),
             ('Confidentiality', 'May contain internal aggregated values and file paths'),
             ('Full details', 'Use root-level combined CSV and analysis/column CSV reports')]
    sheets = [('Overview', overview), ('Columns', columns), ('Patterns', patterns_sheet),
              ('Run Comparison', comparisons), ('Notes', notes)]
    out = io.BytesIO()
    with zipfile.ZipFile(out, 'w', compression=zipfile.ZIP_DEFLATED) as archive:
        archive.writestr('[Content_Types].xml', '<?xml version="1.0" encoding="UTF-8"?>'
            '<Types xmlns="http://schemas.openxmlformats.org/package/2006/content-types">'
            '<Default Extension="rels" ContentType="application/vnd.openxmlformats-package.relationships+xml"/>'
            '<Default Extension="xml" ContentType="application/xml"/>'
            '<Override PartName="/xl/workbook.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet.main+xml"/>'
            '<Override PartName="/xl/styles.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.styles+xml"/>'
            + ''.join(f'<Override PartName="/xl/worksheets/sheet{i}.xml" ContentType="application/vnd.openxmlformats-officedocument.spreadsheetml.worksheet+xml"/>' for i in range(1, len(sheets)+1)) + '</Types>')
        archive.writestr('_rels/.rels', '<?xml version="1.0" encoding="UTF-8"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            '<Relationship Id="rId1" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/officeDocument" Target="xl/workbook.xml"/></Relationships>')
        archive.writestr('xl/workbook.xml', '<?xml version="1.0" encoding="UTF-8"?>'
            '<workbook xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main" xmlns:r="http://schemas.openxmlformats.org/officeDocument/2006/relationships">'
            '<sheets>' + ''.join(f'<sheet name="{escape(name)}" sheetId="{i}" r:id="rId{i}"/>' for i,(name,_) in enumerate(sheets,1)) + '</sheets></workbook>')
        archive.writestr('xl/_rels/workbook.xml.rels', '<?xml version="1.0" encoding="UTF-8"?>'
            '<Relationships xmlns="http://schemas.openxmlformats.org/package/2006/relationships">'
            + ''.join(f'<Relationship Id="rId{i}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/worksheet" Target="worksheets/sheet{i}.xml"/>' for i in range(1,len(sheets)+1))
            + f'<Relationship Id="rId{len(sheets)+1}" Type="http://schemas.openxmlformats.org/officeDocument/2006/relationships/styles" Target="styles.xml"/></Relationships>')
        archive.writestr('xl/styles.xml', '<?xml version="1.0" encoding="UTF-8"?>'
            '<styleSheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
            '<fonts count="2"><font><sz val="11"/><name val="Aptos"/></font><font><b/><color rgb="FFFFFFFF"/><sz val="11"/><name val="Aptos"/></font></fonts>'
            '<fills count="3"><fill><patternFill patternType="none"/></fill><fill><patternFill patternType="gray125"/></fill><fill><patternFill patternType="solid"><fgColor rgb="FF193454"/><bgColor indexed="64"/></patternFill></fill></fills>'
            '<borders count="1"><border><left/><right/><top/><bottom/><diagonal/></border></borders>'
            '<cellStyleXfs count="1"><xf numFmtId="0" fontId="0" fillId="0" borderId="0"/></cellStyleXfs>'
            '<cellXfs count="2"><xf numFmtId="0" fontId="0" fillId="0" borderId="0" xfId="0"/><xf numFmtId="0" fontId="1" fillId="2" borderId="0" xfId="0" applyFill="1" applyFont="1"/></cellXfs>'
            '</styleSheet>')
        for idx, (_, rows) in enumerate(sheets,1):
            row_data = []
            for rn, fields in enumerate(rows, 1):
                cells = ''.join(_xlsx_cell(value, rn, j+1, rn==1) for j,value in enumerate(fields))
                row_data.append(f'<row r="{rn}">{cells}</row>')
            wide = max((len(x) for x in rows), default=2)
            cols = '<cols>' + ''.join(f'<col min="{j}" max="{j}" width="{37 if j==1 else 23}" customWidth="1"/>' for j in range(1, wide+1)) + '</cols>'
            xml = ('<?xml version="1.0" encoding="UTF-8"?>'
                   '<worksheet xmlns="http://schemas.openxmlformats.org/spreadsheetml/2006/main">'
                   '<sheetViews><sheetView workbookViewId="0"><pane ySplit="1" topLeftCell="A2" activePane="bottomLeft" state="frozen"/></sheetView></sheetViews>'
                   f'{cols}<sheetData>{"".join(row_data)}</sheetData>'
                   f'<autoFilter ref="A1:{_xlsx_cell_ref(len(rows),wide)}"/></worksheet>')
            archive.writestr(f'xl/worksheets/sheet{idx}.xml', xml)
    return out.getvalue()


def write_binary_hadoop(spark, destination, payload):
    """Use Hadoop copyFromLocalFile so XLSX works on local FS and HDFS."""
    fs, path = fs_path(spark, destination)
    if fs.exists(path):
        raise FileExistsError(f'File already exists: {destination}')
    fs.mkdirs(path.getParent())
    with tempfile.NamedTemporaryFile(prefix='dv43_xlsx_', suffix='.xlsx', delete=False) as temp:
        temp.write(payload)
        local_name = temp.name
    try:
        local_path = spark._jvm.org.apache.hadoop.fs.Path('file://' + local_name)
        fs.copyFromLocalFile(False, False, local_path, path)
    finally:
        os.unlink(local_name)
