"""Fixed-width UTF-8 *text* input support for DataValidations v4.2.

Column positions and widths are 1-based Unicode character positions. By default,
non-ASCII records are rejected to avoid mistaking bytes for characters.

Do not use for mainframe binary, EBCDIC, packed-decimal, or record-based files.
"""
from pyspark.sql import functions as F


SUPPORTED_TYPES = {'string', 'int', 'integer', 'long', 'double', 'decimal', 'date'}
SUPPORTED_TRIMS = {'left', 'right', 'both', 'none'}


def validate_layout(spec, label):
    """Validate a layout without starting Spark; return standardized fields, width."""
    if not isinstance(spec, dict):
        raise ValueError(f'{label} fixed_width settings must be a JSON object.')
    fields = spec.get('fields')
    if not isinstance(fields, list) or not fields:
        raise ValueError(f'{label} fixed_width requires a nonempty fields list.')
    normalized = []
    names, occupied = set(), set()
    for index, field in enumerate(fields, 1):
        if not isinstance(field, dict):
            raise ValueError(f'{label} field #{index} must be an object.')
        unknown = set(field) - {'name', 'start', 'length', 'type', 'trim',
                                'precision', 'scale', 'implied_decimals', 'date_format'}
        if unknown:
            raise ValueError(f'{label} field #{index}: unknown options {sorted(unknown)}.')
        name = field.get('name')
        if not isinstance(name, str) or not name.strip():
            raise ValueError(f'{label} field #{index} must have a nonempty name.')
        from_name = name.strip().replace(' ', '_')
        if from_name.casefold() in names:
            raise ValueError(f'{label} duplicate normalized field name: {name}.')
        names.add(from_name.casefold())
        start, width = field.get('start'), field.get('length')
        if type(start) is not int or start < 1 or type(width) is not int or width < 1:
            raise ValueError(f'{label} {name}: start and length must be positive integers (start is 1-based).')
        span = set(range(start, start + width))
        if span & occupied:
            raise ValueError(f'{label} {name}: layout fields overlap.')
        occupied.update(span)
        kind = str(field.get('type', 'string')).lower()
        if kind not in SUPPORTED_TYPES:
            raise ValueError(f'{label} {name}: unsupported type {kind!r}.')
        trim = str(field.get('trim', 'right' if kind == 'string' else 'both')).lower()
        if trim not in SUPPORTED_TRIMS:
            raise ValueError(f'{label} {name}: trim must be one of {sorted(SUPPORTED_TRIMS)}.')
        precision, scale = field.get('precision', 20), field.get('scale', 2)
        implied = field.get('implied_decimals', 0)
        if kind == 'decimal':
            if type(precision) is not int or type(scale) is not int or not (1 <= precision <= 38) or not (0 <= scale <= precision):
                raise ValueError(f'{label} {name}: invalid decimal precision/scale.')
            if type(implied) is not int or not (0 <= implied <= 10):
                raise ValueError(f'{label} {name}: implied_decimals must be between 0 and 10.')
            if implied > scale:
                raise ValueError(f'{label} {name}: scale must be >= implied_decimals.')
        elif any(k in field for k in ('precision', 'scale', 'implied_decimals')):
            raise ValueError(f'{label} {name}: precision, scale and implied_decimals require type decimal.')
        if kind != 'date' and 'date_format' in field:
            raise ValueError(f'{label} {name}: date_format is only valid for type date.')
        if kind == 'date' and (not isinstance(field.get('date_format', 'yyyyMMdd'), str)
                               or not field.get('date_format', 'yyyyMMdd')):
            raise ValueError(f'{label} {name}: date_format must be a string.')
        normalized.append({**field, 'name': name, 'type': 'int' if kind == 'integer' else kind, 'trim': trim})
    max_position = max(f['start'] + f['length'] - 1 for f in normalized)
    expected = spec.get('record_length', max_position)
    if type(expected) is not int or expected < max_position:
        raise ValueError(f'{label}: record_length must be >= last field position ({max_position}).')
    on_malformed = spec.get('on_malformed', 'fail')
    if on_malformed not in ('fail', 'report'):
        raise ValueError(f'{label}: on_malformed must be fail or report.')
    for bool_opt in ('skip_blank_lines', 'ascii_only'):
        if not isinstance(spec.get(bool_opt, True if bool_opt == 'ascii_only' else False), bool):
            raise ValueError(f'{label}: {bool_opt} must be true or false.')
    prefixes = spec.get('ignore_prefixes', [])
    if not isinstance(prefixes, list) or any(not isinstance(p, str) or not p for p in prefixes):
        raise ValueError(f'{label}: ignore_prefixes must be a list of nonempty strings.')
    return normalized, expected


def _trim(expr, how):
    if how == 'both':
        return F.trim(expr)
    if how == 'right':
        return F.rtrim(expr)
    if how == 'left':
        return F.ltrim(expr)
    return expr


def parse_fixed_width(spark, uri, spec, null_values, label):
    """Return (typed DataFrame, per-column conversion issues, metadata).

    Malformed-length/non-ASCII lines are excluded from the comparison and
    included in a separate Spark DataFrame for an audit. They cause the run to
    fail (also if on_malformed='report'), rather than pass silently.
    """
    fields, expected = validate_layout(spec, label)
    raw = spark.read.text(uri)
    if spec.get('skip_blank_lines', False):
        raw = raw.where(F.length(F.trim(F.col('value'))) > 0)
    for prefix in spec.get('ignore_prefixes', []):
        raw = raw.where(~F.col('value').startswith(prefix))
    actual_len = F.length(F.col('value'))
    nonascii = (F.length(F.encode(F.col('value'), 'UTF-8')) != actual_len) if spec.get('ascii_only', True) else F.lit(False)
    bad_len = (actual_len != F.lit(expected))
    reason = (F.when(nonascii, F.lit('NON_ASCII_RECORD'))
              .when(bad_len, F.lit('INCORRECT_RECORD_LENGTH')))
    malformed = (raw.where(nonascii | bad_len)
                 .select(F.col('value').alias('Raw_record'),
                         actual_len.alias('Actual_length'),
                         F.lit(expected).alias('Expected_length'),
                         reason.alias('Reason')))
    malformed_count = malformed.count()
    if malformed_count:
        valid = raw.where(~(nonascii | bad_len))
    else:
        valid = raw
    fields_expr = [_trim(F.substring(F.col('value'), f['start'], f['length']), f['trim']).alias(f['name'])
                   for f in fields]
    df = valid.select(*fields_expr)
    # Normalize literal null tokens BEFORE type conversion, preserving blanks as NULL.
    for field in fields:
        n = field['name']
        raw_expr = F.col('`' + n.replace('`', '``') + '`')
        df = df.withColumn(n, F.when(raw_expr.isin([str(v) for v in null_values]), F.lit(None))
                           .otherwise(raw_expr))
    conversions = []
    conversion_errors = []
    for field in fields:
        kind, name = field['type'], field['name']
        if kind == 'string':
            continue
        raw_expr = F.col('`' + name.replace('`', '``') + '`')
        if kind == 'decimal':
            sqltype = f"decimal({field.get('precision', 20)},{field.get('scale', 2)})"
            implied = field.get('implied_decimals', 0)
            if implied:
                converted = (raw_expr.cast('decimal(38,0)') /
                             F.lit(str(10 ** implied)).cast('decimal(38,0)')).cast(sqltype)
            else:
                converted = raw_expr.cast(sqltype)
        elif kind == 'date':
            converted = F.to_date(raw_expr, field.get('date_format', 'yyyyMMdd'))
        else:
            converted = raw_expr.cast(kind)
        conversions.append((name, converted))
    if conversions:
        # No raw records are pulled to driver; only aggregated counts.
        measures = [F.sum(F.when(F.col('`' + name.replace('`', '``') + '`').isNotNull() &
                                 expr.isNull(), 1).otherwise(0)).alias(f'n{i}')
                    for i, (name, expr) in enumerate(conversions)]
        result = df.agg(*measures).first()
        for i, (name, _) in enumerate(conversions):
            count = int(result[f'n{i}'] or 0)
            if count:
                conversion_errors.append((name, count, 'INVALID_FIXED_WIDTH_TYPE'))
        for name, expr in conversions:
            df = df.withColumn(name, expr)
    metadata = {'format': 'fixed_width', 'record_length': expected,
                'malformed_rows': int(malformed_count),
                'on_malformed': spec.get('on_malformed', 'fail'),
                'layout': [{k: v for k, v in f.items() if k != 'trim'} for f in fields],
                'malformed_frame': malformed}
    return df, conversion_errors, metadata
