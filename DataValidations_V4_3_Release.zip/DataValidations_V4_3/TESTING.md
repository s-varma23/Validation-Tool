# Testing and validation — V4.3

## Performed during release construction

- `python -m compileall` — Python compilation passed for code and tests.
- `python -m unittest discover -s tests -q` — **67 discovered; 39 passed and 28 skipped**. Skipped tests require PySpark and a Spark/Java runtime; they were not executed, and their results must not be assumed.
- Generated a self-contained HTML dashboard using synthetic data and verified pattern and run comparison sections and escaped content.
- Created a synthetic five-sheet Excel workbook using the same V4.3 workbook exporter, then verified it could be imported into an Excel-compatible spreadsheet engine; the ZIP archive passed integrity and XML parsing checks.
- No real business input data used to test the release.

## Required Cloudera integration smoke test

Run the included `examples/quickstart_v43.json` from the extracted directory using two small CSV files, then run a second comparison with `--compare_run` pointing to the first JSON summary. Confirm:

- First-unique-PK early-exit still chooses the expected first candidate.
- Mismatch counts and per-column CSVs match the existing approved version.
- Overall files are root-level CSV files for small runs; individual column CSVs are directly in `analysis/`.
- `DataValidation_discrepancy_patterns.csv` totals for deliberate repeated patterns are correct.
- Workbook opens in Excel with five expected tabs.
- Run comparison correctly identifies changed column counts, and incompatible baselines fail safely.
- A repeated `--run_id` refuses to overwrite completed files.
- `DataValidation_run_manifest.json` appears on completed runs and `_RUN_IN_PROGRESS.json` is removed.
- Performance benchmark can compare elapsed times with/without patterns and workbook using the included CLI toggles.

## Explicit limitations

- Does **not** guarantee every company's Cloudera Spark minor version supports all Spark functions without integration testing.
- Pattern grouping by exact field values can be expensive for highly unique wide datasets; disable or tune patterns if performance proves unacceptable.
- File size/mtime and Python module hashes provide an audit trail, not full cryptographic input file verification.
- Historical comparisons use run-level metrics and column counts, not record-level change resolution.
