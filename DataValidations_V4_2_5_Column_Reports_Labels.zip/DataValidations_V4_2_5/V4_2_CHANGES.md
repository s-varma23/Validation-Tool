# Version 4.2 changes

- Added Spark fixed-width text parser (`data_validation_fixedwidth.py`)
- Accepted `inputs.File1` / `inputs.File2` with `format: fixed_width` and independent field positions
- Preserved CSV-only operation without new settings
- Added mixed fixed-width/CSV comparisons through the same reports and dashboard
- Supports type conversion, implied-decimal fields, string padding/trimming, leading-zero-preserving identifiers
- Added explicit malformed-row auditing (wrong record width/non-ASCII) with fail/report modes
- Includes input layout and parse/malformed metadata in run summary and HTML dashboard
- Added layout-validation unit tests and four Spark integration scenarios
- Preserved existing logging, explicit key configuration and first-unique-key automatic early exit

Limitation: Only line-oriented UTF-8 text is supported, with character-position layouts; not mainframe binary or copybook formats. Production Spark integration tests have not been run in this environment.
