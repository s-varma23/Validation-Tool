# Version 4.2.1 — Combined differences CSV fix

## Symptom
`DataValidation_differencesall_records.csv/` contained a large number of `part-*.csv` files even when the report had only a small number of mismatched records. Spark created them based on upstream partitions, not intentionally one per mismatch.

## Behavior
- For 0 through 5,000 mismatched records (configurable), Spark `coalesce(1)` writes a single CSV part and the Hadoop filesystem rename changes its name to `differences_all_records.csv` within the existing report directory.
- For more than 5,000 mismatched records, Spark retains multiple part files by default to avoid a potentially large single-task bottleneck. The 5,000-row limit is configurable with `spark.single_csv_max_rows`.
- The same report format and the V4.2 directory name remain unchanged. The output directory is still named `DataValidation_differencesall_records.csv/`; the actual data file is `differences_all_records.csv` inside it.
- Per-column CSV reports, HTML dashboards, schema audits, fixed-width support, and automatic early-exit PK selection remain unchanged.
- No need to concatenate CSVs manually or `.collect()` discrepancy rows.

## Example configuration

```json
{"spark": {"single_csv_max_rows": 5000}}
```

## Run (after copying the three Python files to `/home/svarma`)

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_fixedwidth.json \
  --output_dir file:///home/svarma/DataValidation_Results \
  --run_id v421_test
```

## Validation

```bash
python -m unittest discover -s tests -v
```

Non-Spark unit tests can run without PySpark. Spark integration tests require your Cloudera Spark 3 environment.
