# DataValidations V4.2.5 — Visible column CSVs and environment labels

This release builds on V4.2.4, preserving the validation engine and **first-unique non-null key, early-exit** PK selection rule.

## Column-level discrepancy CSV files

- A completed run writes one **actual CSV file** for every affected column directly in `analysis/` (not subfolders such as `For_column=...`). Example: `analysis/Column_wbwithdrawaldelay_differences.csv`.
- For unusual column names, the filename is sanitized and a short hash is added to prevent collisions.
- `analysis/DataValidation_column_report_index.csv` lists **Column_affected**, **Mismatch_rows**, and **CSV_file** for every column with discrepancies. For example, `wbwithdrawaldelay,22106,analysis/Column_wbwithdrawaldelay_differences.csv`.
- The HTML dashboard has an **Open CSV** link beside every affected column in its ranked column summary. The Output artifacts section also links to the CSV index and all column reports.
- The tool verifies the existence of all expected column CSV files before reporting success. If mismatched records exist but no affected columns can be identified, the run fails instead of silently leaving reports missing.
- An output count is printed in the final command summary: `column_report_count` and `column_report_index`.

## Labels shown to analysts

The CSV exports and dashboard now use:

- **Non-Production** (formerly File1): column-level detail `Non-Production`, wide combined report `Non-Production_<column>`, missing-row `Missing_from`, reconciliation totals, audit-source name.
- **Production** (formerly File2): column-level detail `Production`, wide combined report `Production_<column>`, missing-row `Missing_from`, reconciliation totals, audit-source name.

**Compatibility:** Existing `--bigplay_file` / `--daas_file` command-line flags, `inputs.File1` / `inputs.File2` and `column_aliases.File1` / `column_aliases.File2` configuration keys are unchanged. The JSON summary retains historical internal keys such as `file1_rows` for existing consumers, and now includes `environment_labels`. The human-readable report CSV headers are changed; downstream code that reads `File1`, `File2`, `File1_<column>` or `File2_<column>` headers must be updated.

## Run folder

For `--output_dir file:///home/svarma/tmp/dv-results --run_id AccumRC_v425`:

```text
/home/svarma/tmp/dv-results/DataValidation_v4/AccumRC_v425/
├── DataValidation_differencesall_records.csv
├── DataValidation_differencesmissing_records.csv
├── DataValidation_dashboard.html
├── DataValidation_summary.json
├── DataValidation_run.log
├── DataValidation_errors.log
└── analysis/
    ├── DataValidation_column_report_index.csv
    ├── DataValidation_column_summary.csv
    ├── DataValidation_schema_differences.csv
    ├── DataValidation_renamed_columns.csv
    ├── Column_wbwithdrawaldelay_differences.csv
    └── Column_<another_column>_differences.csv
```

There is no column subfolder. Additional analysis reports will appear as applicable. Only columns with mismatches produce `Column_*_differences.csv` files. On a PASS with no value differences, the index is a header-only CSV.

To locate the files in Linux, use:

```bash
find /home/svarma/tmp/dv-results/DataValidation_v4/AccumRC_v425/analysis \
  -maxdepth 1 -type f -name 'Column_*_differences.csv' -print

cat /home/svarma/tmp/dv-results/DataValidation_v4/AccumRC_v425/analysis/DataValidation_column_report_index.csv
```

Use a **new `--run_id`** to avoid confusing V4.2.4 outputs with V4.2.5 artifacts.

## Tests

`python -m unittest discover -s tests -v`

The non-Spark tests run here. Spark end-to-end tests are supplied in `tests/test_v4_spark.py` and `tests/test_v42_fixedwidth.py`, but need execution in a compatible Spark environment. The CSV-flattening writer depends on Hadoop filesystem rename, so remote object stores may require additional handling.
