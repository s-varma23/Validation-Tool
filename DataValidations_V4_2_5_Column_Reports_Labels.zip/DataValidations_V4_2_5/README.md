# Version 4.2.5 — Column CSV visibility and labels

See [V4_2_5_CHANGES.md](V4_2_5_CHANGES.md) for the current layout, direct CSV links, renamed Non-Production / Production report headers, and instructions.

# Version 4.2.4 — Flat report files / clean run folder

Version 4.2.4 makes the final CSV outputs **actual files**, rather than Spark-written directories containing `part-...csv` files. The PK early-exit algorithm, comparison rules, fixed-width parsing, schema validation, error logging and numerical tolerance logic are unchanged.

## Output layout

For example, `--output_dir file:///home/svarma/tmp/dv-results --run_id AccumRC_v424` produces:

```text
/home/svarma/tmp/dv-results/
└── DataValidation_v4/
    └── AccumRC_v424/
        ├── DataValidation_differencesall_records.csv       # single CSV at run root
        ├── DataValidation_differencesmissing_records.csv  # single CSV at run root
        ├── DataValidation_dashboard.html
        ├── DataValidation_summary.json
        ├── DataValidation_run.log
        ├── DataValidation_errors.log
        └── analysis/
            ├── DataValidation_column_summary.csv
            ├── DataValidation_schema_differences.csv
            ├── DataValidation_invalid_conversions.csv
            ├── DataValidation_data_quality.csv
            ├── DataValidation_column_name_audit.csv
            ├── DataValidation_renamed_columns.csv
            ├── DataValidation_top_affected_keys.csv        # only when differences, top_keys_limit > 0
            ├── DataValidation_aggregate_reconciliation.csv # when configured
            ├── DataValidation_malformed_File1.csv          # when File1 is fixed-width
            ├── DataValidation_malformed_File2.csv          # when File2 is fixed-width
            ├── Column_AMOUNT_<8-character-hash>.csv        # one per impacted column
            └── Column_STATUS_<8-character-hash>.csv
```

There are **no nested CSV report directories** in the finished run. The eight-character suffix prevents two differently spelled columns from generating the same filename. The JSON summary's `column_report_files` object maps the actual field name to its filename. The offline HTML dashboard links to these files directly.

Overall differences remain **one row per mismatching PK**, containing only impacted columns (the V4.2.3 behavior). Missing records remain in one combined CSV containing rows missing from either input. Detailed per-column files still contain PK, affected column, File1 and File2, plus numeric difference diagnostics.

## Run on Cloudera

Copy the updated `data_Validation_comp_v4.py` and `data_validation_dashboard.py` into `/home/svarma/`; retain `data_validation_fixedwidth.py` in the same directory. For fixed-width inputs, keep your actual JSON configuration. Example:

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_fixedwidth.json \
  --output_dir file:///home/svarma/tmp/dv-results \
  --run_id AccumRC_v424 \
  --spark_log_level WARN
```

Use your own `--config`, `--bigplay_file`, and `--daas_file` values. CSV-to-CSV continues to work. Always use a **new `--run_id`** when switching to this release so stale Spark output folders from an older run don't appear next to the new flat CSV files. The tool only overwrites known output filenames for the chosen run ID; it does not recursively clean old output layout directories.

## Behavior and considerations

- Spark internally writes temporary CSV output directories, then moves one CSV part-file into the final location using Hadoop FileSystem APIs. Temporary directories are deleted after each successful write or on error. `file:///`, HDFS, and file systems supporting Hadoop rename are supported. Object stores with non-atomic rename semantics may require adaptation.
- Overall and analysis CSVs are forced to **a single output part** to keep each report as a named file. This makes browsing easier but means very large discrepancy datasets (millions of rows) can incur a single-task bottleneck. `spark.single_csv_max_rows` is retained for compatibility with older configuration files but no longer splits overall output in this flat-file release.
- Per-column CSVs still use a single hash repartition by the column to avoid repeating a whole Spark join and write for each field. Each impacted field gets one file inside `analysis/`.
- Spark metadata (`_SUCCESS`, `.crc`, temporary directories) is removed with staging folders. Some local Hadoop file systems may still create hidden checksum sidecars alongside the published CSV files.
- The output folder is still organized by `DataValidation_v4/<run_id>` under `--output_dir`. Only the *contents of each run* have been flattened.

## Testing

Run: `python -m unittest discover -s tests -v`. Unit tests are runnable without Spark. Spark integration tests for output correctness and folder layout require Spark/Java installed. This package was syntax-checked, and non-Spark tests passed in the build environment, but the full Spark tests have **not yet been run in Cloudera**.

---

# Version 4.2.3 — Impacted columns only in combined discrepancies

`DataValidation_differencesall_records.csv/` now includes **only fields with at least one discrepancy** (across the full validation run), plus the key and `Columns_effected`. For each such field, the report contains side-by-side `File1_<column>` and `File2_<column>` values. Example: `ID,Columns_effected,File1_DELAY,File2_DELAY,File1_AMOUNT,File2_AMOUNT`.

- Still **one row per affected PK**. The key-selection algorithm is unchanged: check candidates in order, stop after finding the first unique, non-null column in both files.
- The columns are chosen *across the run*, so a field that changed for policy A appears for policy B too; for policy B, the field may show equal File1/File2 values. `Columns_effected` distinguishes exactly what changed on each policy.
- The existing column-specific reports, their one-part-per-column behavior, the dashboard, schema audit, fixed-width support, error logging, and missing-record reports are unchanged.
- The column-level summary is calculated **before** writing the combined report; it is reused to select impacted fields, with no extra full input scan.
- Summary JSON now includes `impacted_columns` (the impacted field names in source order), separate from `columns_compared` (all fields checked).
- With default `spark.single_csv_max_rows=5000`, the combined output may still be multiple part CSVs for ~22,000 affected records. To force one CSV for 22,000 rows, set `"single_csv_max_rows": 50000` under `spark` (only when the dataset width and server resources permit it).
- Empty-difference runs write a header-only combined report containing the key and `Columns_effected`.

Note: `File1_` and `File2_` are source-side labels (not source column renames). Any automation consuming the older `uat_`/`prod_` headers in this combined report will need updating.

Run on Cloudera (use your real paths, adjust `--config` to your actual JSON):

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_fixedwidth.json \
  --output_dir file:///home/svarma/DataValidation_Results \
  --run_id impacted_only_test \
  --spark_log_level WARN
```

Test with `python -m unittest discover -s tests -v`. Tests which need Spark are skipped when it is absent.

---

# Version 4.2.2 output-partition fix

Per-column discrepancy folders now use `.repartition(output_partitions, F.col("For_column"))` before `partitionBy("For_column")`: with standard Spark settings each affected column normally gets one CSV part-file, not one per generic Spark partition. An affected column with ~22,000 records is not divided into eight separate part CSVs by `output_partitions=8`. The `DataValidation_differencesall_records.csv` wide report is unaffected. **This is a partitioning fix, not a change to any mismatch counts or PK identification.**

# DataValidations Version 4.2.1 — fixed-width `.txt` support

Version 4.2.1 is built on Version 4.1. It accepts **CSV**, **line-oriented fixed-width UTF-8 text**, and **mixed CSV/fixed-width comparisons**. It retains the same PK selection strategy: scan columns in File1 order and **stop on the first column that is unique and non-NULL in both datasets**. The original per-column discrepancy CSVs, self-contained HTML dashboard, rename audit, thresholds, and error logging remain available.

## Quick start using included sample data

Run from the extracted package directory after copying the *whole package* to an approved Spark-enabled machine:

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files data_validation_dashboard.py,data_validation_fixedwidth.py \
  data_Validation_comp_v4.py \
  --config examples/quickstart_fixed_width_config.json
```

The sample compares `examples/fixed_width_demo.txt` with `examples/fixed_width_target_demo.csv`. It contains three policies and a deliberate premium discrepancy. The demo output is `file:///tmp/DataValidation_v42_Examples/DataValidation_v4/fixed_width_example`. Edit `output_dir` to write under your home directory.

### Run against two fixed-width `.txt` files in your home folder

1. Copy `data_Validation_comp_v4.py`, **`data_validation_dashboard.py`** and **`data_validation_fixedwidth.py`** into `/home/svarma/`.
2. Copy `validation_fixedwidth.example.json` to `/home/svarma/validation_fixedwidth.json` and **replace every field position and filename with your actual layout**. The included 39-character sample is invented for demonstration; do not apply it blindly to business data.
3. Run:

```bash
spark3-submit --master 'local[2]' \
  --conf spark.ui.showConsoleProgress=false \
  --py-files /home/svarma/data_validation_dashboard.py,/home/svarma/data_validation_fixedwidth.py \
  /home/svarma/data_Validation_comp_v4.py \
  --config /home/svarma/validation_fixedwidth.json \
  --output_dir file:///home/svarma/DataValidation_Results \
  --run_id fixed_oct15
```

For one fixed-width file and one CSV file, use `validation_csv_vs_fixedwidth.example.json` instead. Use `--bigplay_file` and `--daas_file` if you want to override input paths from the configuration. To compare two CSVs, **no `inputs` configuration is required**, so Version 4.1-style execution still works.

**Tip for Cloudera:** `--py-files` must list both companion Python modules. If all three files are in `/home/svarma`, it can also work without `--py-files` in local mode, but passing them explicitly is more portable.

## Understanding a fixed-width layout

The following 39-character text line is the synthetic example:

```text
00000001JANE DOE      000125050ACTIVE  
```

The line consists of four fields. Offsets are **1-based** and a field's last character is `start + length - 1`:

| Column | Start | Length | Positions | Type | Comments |
|---|---:|---:|---|---|---|
| Policy Number | 1 | 8 | 1–8 | string | Leading zeroes preserved |
| Customer Name | 9 | 14 | 9–22 | string | Right-space trimmed |
| Premium | 23 | 9 | 23–31 | decimal | `000125050` with 2 implied decimals = `1250.50` |
| Status | 32 | 8 | 32–39 | string | Right-space trimmed |

A field definition in JSON:

```json
{
  "name": "Premium",
  "start": 23,
  "length": 9,
  "type": "decimal",
  "precision": 15,
  "scale": 2,
  "implied_decimals": 2
}
```

Supported `type`: `string`, `int`, `integer`, `long`, `double`, `decimal`, `date`. Dates support `date_format` such as `yyyyMMdd`; strings support `trim`: `none`, `left`, `right` (default), or `both`. A numeric field's default trim is `both`. Date columns are parsed into Spark dates. Numeric conversion issues contribute to existing `DataValidation_invalid_conversions.csv` and, by default, a `FAIL` validation result. String identifiers should use `type: string` to preserve leading zeros.

For two `.txt` inputs, specify independent layouts in `inputs.File1` and `inputs.File2`. Matching column names should normalize to the same name, or you can use `column_aliases` to map them explicitly.

## Malformed record handling

A record is malformed when its character count differs from the configured `record_length`, or if `ascii_only` is true (the default) and the line contains a non-ASCII character. The record length **does not include** the newline delimiter.

- `on_malformed: "fail"` (default): write the malformed rows to `DataValidation_malformed_File1.csv/` (or File2), then **stop** the validation with an error. This is the safest production setting.
- `on_malformed: "report"`: write the malformed rows, **exclude them from the comparison**, and finish with an overall `FAIL` status. The JSON summary and HTML show the bad-row count. The job will not pretend those rows matched.
- `skip_blank_lines: true`: deliberately ignore blank/whitespace-only lines. Default is false to avoid hiding bad records.
- `ignore_prefixes: ["H", "T"]`: skip specified header/trailer *record types*, but **only** when these prefixes correctly identify every such record. This is NOT a generic “skip the first N rows” feature.

The malformed-record CSV includes the original line in `Raw_record`. These reports, discrepancy samples, and HTML reports may contain confidential customer or financial information: store them only in company-approved locations.

## Text format limitations

Fixed-width parsing here is for **plain, line-oriented UTF-8 text** with one logical record per line. Offsets are character positions; with `ascii_only: true`, a character equals a byte. If your specification counts bytes and contains multibyte characters, don't disable `ascii_only` without converting your layout to character positions. This is **not** a COBOL copybook reader and does not decode EBCDIC, packed COMP-3 numbers, zoned decimals, signed overpunch, binary records, custom code pages, or multiline records. Don't infer the file layout from filename extension alone: a `.txt` file may be tab-delimited or CSV-like.

Missing optional fields, conflicting aliases, duplicate/overlapping field positions, invalid date/decimal formats, malformed physical lines, and schema differences have independent error/audit paths. `record_length` can be larger than the last field's end position (a trailer/pad region), but never smaller.

## Outputs

The ordinary Version 4.1 outputs remain under `DATA_ROOT/DataValidation_v4/RUN_ID`:

- `DataValidation_dashboard.html` — offline interactive discrepancy dashboard, includes malformed-row counts
- `DataValidation_summary.json` — input formats, both fixed layouts, timings and run status
- `DataValidation_differencesall_records.csv/` — matched keys with differing values
- `DataValidation_differences_by_column/` — detailed mismatch CSV per column
- `DataValidation_schema_differences.csv/`, `DataValidation_column_name_audit.csv/` and `DataValidation_renamed_columns.csv/`
- `DataValidation_invalid_conversions.csv/`, `DataValidation_differencesmissing_records.csv/`, `DataValidation_aggregate_reconciliation.csv/`
- `DataValidation_malformed_File1.csv/` and/or `DataValidation_malformed_File2.csv/` — created for fixed-width inputs, even if empty
- `DataValidation_run.log` and `DataValidation_errors.log` — driver-local logs (when output is file://)

**Combined difference report:** with `spark.single_csv_max_rows` set to 5,000 (the default), runs with 0–5,000 mismatched records create exactly **one** file named `DataValidation_differencesall_records.csv/differences_all_records.csv`. The `.csv/` path is a Spark-compatible *directory* and also contains `_SUCCESS` metadata. No report row is written as its own file. Larger reports retain Spark's partitioned output for performance; set a larger safe threshold if you want one file for larger report sizes. This does **not** affect the partitioned per-column folder reports or the early-exit PK behavior.

Spark otherwise writes CSV *directories* with one or more `part-*.csv` files. A run with `on_malformed: fail` stops early, so some later reports may be absent, while the malformed file and Python exception log are still written.

## Validation and tests

```bash
python -m compileall -q data_Validation_comp_v4.py data_validation_dashboard.py data_validation_fixedwidth.py
python -m unittest discover -s tests -v
```

The unit tests work without Spark. Full integration tests need a working PySpark/Spark installation and test end-to-end joins and report writing. **Do not rely on a production fixed-width layout until you've checked a few known rows by hand and run the integration tests on your cluster.**

`benchmark_data_validation_v4.py` remains available for synthetic CSV benchmarks; a future enhancement could benchmark fixed-width parsing separately. No changes were made to the early-exit PK heuristic.
