# V4.2.3: Combined report shows impacted columns only

Replaced full-width combined `all_records` output with a projection of only the columns having at least one discrepancy anywhere in the run. Both source values for each impacted column are included. `Columns_effected` remains per-row, preserving which values actually differ for that key. No pivot or driver-side collection of row-level data. Summary reports `impacted_columns`.

The prior individual column CSV folders, single-file threshold, and early-exit PK decision are unchanged. The pair headers in the combined report are now `File1_<col>` and `File2_<col>` rather than `uat_` and `prod_`.

Spark integration tests cover 3 matched policies, two affected fields, two unaffected fields, and an empty discrepancy run.
