# Version 4.2.2 — single part CSV per affected column

**Cause of 8 CSV files in one folder:** the writer used `.repartition(output_partitions)` followed by `.partitionBy("For_column")`. As a result every worker could write a separate part file in the same column folder, even when only one column had discrepancies.

**Fix:** changed to `.repartition(output_partitions, F.col("For_column"))` so rows with the same `For_column` are assigned to one hash partition. Spark still writes a *directory* containing a `part-*.csv` file and metadata (`_SUCCESS`, optional `.crc`). Large skewed columns may benefit from multiple part files; this fix favors human-readable per-column output over single-column write parallelism.

**Unchanged:** first-unique-column early-exit PK selection, all comparison and numeric-tolerance rules, combined wide report, dashboard, fixed-width ingestion and logging.

**Important:** If an affected column grows very large (millions of rows), forcing one partition for that column may reduce write throughput or cause memory pressure. Test on a representative dataset; add a configurable large-column threshold if needed.

Run tests on a Spark-enabled host:

```bash
python -m unittest discover -s tests -v
```

The new Spark integration regression test verifies that 80 discrepancies for one column produce one part CSV, not eight, while preserving all 80 rows.
