# Version 4.2.4 — Flat report files / clean run folder

Version 4.2.4 makes the final CSV outputs **actual files**, rather than Spark-written directories containing `part-...csv` files. The PK early-exit algorithm, comparison rules, fixed-width parsing, schema validation, error logging and numerical tolerance logic are unchanged.

## Output layout

For example, `--output_dir file:///home/svarma/tmp/dv-results --run_id AccumRC_v424` produces:

```text
/home/svarma/tmp/dv-results/
└── DataValidation_v4/
    └── AccumRC_v424/
        ├── DataValidation_differencesall_records.csv       # single CSV at run root
        ├── DataValidation_differencesmissing_records.csv  # single CSV at run root
        ├── DataValidation_dashboard.html
        ├── DataValidation_summary.json
        ├── DataValidation_run.log
        ├── DataValidation_errors.log
        └── analysis/
            ├── DataValidation_column_summary.csv
            ├── DataValidation_schema_differences.csv
            ├── DataValidation_invalid_conversions.csv
            ├── DataValidation_data_quality.csv
            ├── DataValidation_column_name_audit.csv
            ├── DataValidation_renamed_columns.csv
            ├── DataValidation_top_affected_keys.csv        # only when differences, top_keys_limit > 0
            ├── DataValidation_aggregate_reconciliation.csv # when configured
            ├── DataValidation_malformed_File1.csv          # when File1 is fixed-width
            ├── DataValidation_malformed_File2.csv          # when File2 is fixed-width
            ├── Column_AMOUNT_<8-character-hash>.csv        # one per impacted column
            └── Column_STATUS_<8-character-hash>.csv
```

There are **no nested CSV report directories** in the finished run. The eight-character suffix prevents two differently spelled columns from generating the same filename. The JSON summary's `column_report_files` object maps the actual field name to its filename. The offline HTML dashboard links to these files directly.

Overall differences remain **one row per mismatching PK**, containing only impacted columns (the V4.2.3 behavior). Missing records remain in one combined CSV containing rows missing from either input. Detailed per-column files still contain PK, affected column, File1 and File2, plus numeric difference diagnostics.

